"""Run from the trusted server shell to create a one-hour owner recovery link."""
import os
from pathlib import Path
from store import Store

root = Path(__file__).resolve().parent
db = Store(Path(os.environ.get('HOTELCHAT_DATA_DIR',str(root/'data')))/'hotelchat.sqlite3')
with db.connect() as conn:
    owner = conn.execute("SELECT id FROM users WHERE role='owner' AND disabled=0").fetchone()
if not owner: raise SystemExit('Noch kein Betreiberzugang vorhanden.')
print(os.environ['PUBLIC_URL'].rstrip('/')+'/reset#'+db.reset_link(owner[0]))
