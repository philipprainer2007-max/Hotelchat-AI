# Prüfstand der neuen Serverversion

Stand: 24. November 2026. Die öffentliche Veröffentlichung wurde nicht ausgeführt.

## Automatisierte Prüfungen

**63 Prüfungen bestanden.** Davon 26 für Konten, Serverrechte, Veröffentlichung, Limits und Sicherung sowie 37 für die übernommene Import-, Quellen- und Antwortspeicherlogik. JavaScript-Dateien wurden zusätzlich auf gültige Syntax geprüft.

Ausführen nach Installation der Abhängigkeiten:

```sh
python -m unittest discover -s tests -v
```

Geprüfte Fälle:

- Anonyme Anfragen können keine Hotels verwalten, Quellen importieren oder die Verwaltungs-KI nutzen.
- Hotelkonten sehen nur das zugeordnete Hotel. Fremde Hotelkennungen verschaffen keinen Lese-, Schreib- oder Chat-Zugriff. Hotelkonten können keine Betreiberangaben, KI-Schlüssel, erlaubten Einbau-Adressen oder Plattformfreigaben ändern.
- Namen, Website-Adressen und Hotelinformationen in Gastanfragen überschreiben keine Serverdaten. Es werden nur die gespeicherten Angaben des autorisierten Hotels verwendet.
- Fremde Anfrageherkunft, fehlende CSRF-Token, falsche App-Adresse und HTML in Namen werden abgefangen bzw. als Text dargestellt.
- Anmeldeversuche werden begrenzt; Einladungen und Rücksetzlinks sind zeitlich beschränkt und einmalig. Sperren und Passwortwechsel widerrufen vorhandene Sitzungen.
- Der API-Schlüssel wird verschlüsselt abgelegt. Er wird nicht in Verwaltungsantworten, Gastantworten oder statischen Dateien ausgegeben. Die gespeicherte Verbindung lässt sich entfernen.
- Fehlende Betreiberangaben sperren Demo und öffentlichen Chat. Signierte Gastberechtigungen gelten nur für das passende Hotel und die jeweilige Profilversion und laufen ab.
- Zwei getrennte Gastgespräche erhalten verschiedene Berechtigungen. Persönliche Testnachrichten aus einem Verlauf erscheinen weder im anderen KI-Kontext noch in der Datenbank.
- Gleichzeitige Budgetreservierungen überschreiten das eingestellte Limit nicht. Bei unbekannten Abrechnungsdaten oder Zeitüberschreitung bleibt die Reservierung bestehen. Bereits belegte öffentliche FAQ-Antworten können auch bei ausgeschöpftem Budget wiederverwendet werden.
- Antwortspeicher gilt exakt 24 Stunden, wird nicht durch Lesen verlängert und wird bei Änderungen an Hotelwissen, Name oder eigenen Fakten nicht wiederverwendet. Neue Fragen, andere Sprachen, Verneinungen und private Gesprächsbezüge werden nicht unscharf vermischt.
- Quellen und Cache bleiben zwischen Hotels getrennt. Unbestätigte Aussagen, falsche Zitate und fehlende Angaben führen nicht zu erfundenen Detailantworten in den kontrollierten Testfällen.
- Private Importziele, fremde Weiterleitungen und nicht erlaubte Bereiche werden abgefangen. Der Import verwendet die gespeicherte Hotelwebsite, nicht eine vom Gast oder Client untergeschobene Adresse.
- Eine Sicherung wurde als einzelne SQLite-Datei ohne WAL-/SHM-Begleitdateien in einen getrennten Ordner kopiert. Konsistenzprüfung, Anmeldung, Hotelprofil und Quellen funktionierten anschließend. Sicherungsdateien sind nur für den Dateieigentümer lesbar.

## Prüfung im laufenden Dienst

- Gunicorn startete mit einem Worker und acht Threads; der Healthcheck antwortete mit HTTP 200. Der temporäre Testdienst wurde anschließend beendet.
- Die bisherige Vorschau auf Port 8794 antwortete weiterhin mit HTTP 200 und bestehender KI-Verbindung. Der neue lokale Dienst auf Port 8795 antwortete ebenfalls erfolgreich.
- Kontrollzentrum in einer isolierten Testumgebung geöffnet, Hotelprofil und Freigabe-/Einbaubereich angesehen und gespeichert. Interne Vorschau gestartet und eine mit Quellen versehene Testantwort ohne Kostenanzeige erhalten.
- Auf einer separaten lokalen Beispielwebsite erschien der Chatbutton. Ein Klick öffnete das eingebettete Fenster auf derselben Seite mit Datenschutzhinweis vor dem KI-Start. Ein Screenshot liegt im übergeordneten `outputs`-Ordner.
- Der Startknopf innerhalb des fremden eingebetteten Fensters ließ sich mit dem verwendeten Browsersteuerungswerkzeug nicht zuverlässig anklicken. Der öffentliche Start- und Antwortablauf wurde deshalb zusätzlich direkt gegen die laufenden HTTP-Endpunkte geprüft: signierte Berechtigung, passende Hotelkennung, belegte Antwort und keine Kostendaten in der Gastantwort. Eine vollständige manuelle Bedienprüfung der Einbettung auf der echten Hotelwebsite steht noch aus.

Die neuen KI-Prüfungen verwenden einen kontrollierten Anbieterersatz. Sie testen die Daten- und Zugriffswege und verursachen keine neuen Anthropic-Gebühren. Sie sind kein Beleg, dass ein Sprachmodell jede beliebige Frage sachlich richtig beantworten wird.

## Vor echtem Gästebetrieb offen

- Anmeldung im Render-Konto; Repository-Anbindung und Veröffentlichung unter der endgültigen HTTPS-Adresse. Der Browser zeigte eine Render-Anmeldeseite. Weder Hostingvertrag noch kostenpflichtiger Plan wurden bestätigt.
- Betreiberzugang durch den Nutzer selbst anlegen und Anthropic-Schlüssel direkt in der neuen Verwaltung hinterlegen. Die bisherige nur im Arbeitsspeicher liegende Verbindung wurde nicht ausgelesen oder übernommen.
- Betreiberangaben und die zum Hotel, den Anbietern und dem tatsächlichen Konto passenden rechtlichen Informationen und Verträge ergänzen bzw. prüfen. Die Gastfreigabe bleibt bis dahin gesperrt.
- Off-Site-Sicherung zusätzlich zu den täglichen Sicherungen auf dem Servicedatenträger verbinden.
- Fachliche Antwortprüfung mit aktuellen Hotelinformationen, tatsächliche Einbettung, Mobil-/Tastaturtests und angemessene Lastprüfung unter den realen Hostingbedingungen.

Die Version ist eine technisch vorbereitete, lokal geprüfte Grundlage für die Veröffentlichung. Sie ist noch nicht öffentlich live oder unabhängig sicherheitsgeprüft.

Zusätzlich geprüft: nur der Betreiber kann einen vollständigen verschlüsselten Export erstellen; die Wiederherstellung erhält mehrere getrennte Hotels, Konten und Quellen. Falsches Sicherungspasswort und das Überschreiben eines belegten Ordners werden abgelehnt. Alte Sitzungen und Einladungen werden beim Wiederherstellen nicht reaktiviert.

## Nachprüfung der echten KI-Verbindung

Am 24. November wurden zusätzlich gezielte Fragen über die tatsächlich verbundene Anthropic-API gestellt. Dabei wurde ein zu niedriges Ausgabelimit gefunden: Auch die nativen Quellenzitate verbrauchen Ausgabetokens. Eine kombinierte Frage konnte deshalb trotz korrekter Fakten am Limit enden und vollständig verworfen werden. Das Limit wurde auf 1600 Ausgabetokens gesetzt; die vorsorgliche Budgetreservierung berücksichtigt diese Grenze. Vollständige belegte Sätze können bei einer dennoch gekürzten Antwort als ausdrücklich markierte Teilantwort erhalten bleiben; unvollständige Sätze werden verworfen und solche Teilantworten nicht im öffentlichen FAQ-Speicher gespeichert.

Der erneute Live-Test lieferte die genaue Adresse und die aktuellen Haustierbedingungen einschließlich 25 Euro pro Tag aus den eingelesenen Quellen. Eine verbindliche Zimmerverfügbarkeit für den Folgetag wurde nicht erfunden. Diese Prüfungen beziehen sich auf das normale Beispielprofil; alle Hotels verwenden dieselbe allgemeine Logik.

Die Gastfußzeile zeigt einen neutralen Concierge-Hinweis. Sie behauptet bei einer unbelegten oder gekürzten KI-Antwort nicht mehr fälschlich, dass keine KI verbunden sei.
