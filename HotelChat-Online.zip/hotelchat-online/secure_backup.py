"""Passphrase-encrypted complete exports, including the separate vault key."""
import base64
import io
import json
import os
import sqlite3
import tempfile
import zipfile
from contextlib import closing
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

from backup import create_backup

HEADER = b'HOTELCHAT-BACKUP-v1\n'


def encryption_key(passphrase, salt):
    if not isinstance(passphrase,str) or not 16<=len(passphrase)<=256:
        raise ValueError('Bitte ein eigenes Sicherungspasswort mit 16 bis 256 Zeichen wählen.')
    return base64.urlsafe_b64encode(Scrypt(salt=salt,length=32,n=2**15,r=8,p=1).derive(passphrase.encode()))


def encrypted_export(data, master, passphrase):
    salt = os.urandom(16)
    cipher = Fernet(encryption_key(passphrase,salt))
    with tempfile.TemporaryDirectory(prefix='hotelchat-export-') as directory:
        snapshot = create_backup(data,directory)
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as archive:
            archive.write(snapshot,'hotelchat.sqlite3')
            archive.writestr('vault.json',json.dumps({'format':1,'master':master}))
        return HEADER+salt+cipher.encrypt(buffer.getvalue())


def restore_export(payload, passphrase, destination):
    if not payload.startswith(HEADER) or len(payload)>300_000_000:
        raise ValueError('Ungültige oder zu große HotelChat-Sicherung.')
    offset = len(HEADER)
    salt = payload[offset:offset+16]
    try:
        raw = Fernet(encryption_key(passphrase,salt)).decrypt(payload[offset+16:])
    except (InvalidToken,ValueError):
        raise ValueError('Sicherungspasswort falsch oder Sicherungsdatei beschädigt.') from None
    destination = Path(destination)
    # Never overwrite a live database or extract arbitrary paths from an archive.
    if destination.exists() and any(destination.iterdir()):
        raise ValueError('Zur Wiederherstellung bitte einen neuen, leeren Ordner verwenden.')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        if set(archive.namelist())!={'hotelchat.sqlite3','vault.json'} or any(x.file_size>300_000_000 for x in archive.infolist()):
            raise ValueError('Unbekannter Sicherungsinhalt.')
        vault = json.loads(archive.read('vault.json'))
        if vault.get('format')!=1 or not isinstance(vault.get('master'),str) or len(vault['master'])<32:
            raise ValueError('Die Sicherung enthält keinen gültigen Hauptschlüssel.')
        database = archive.read('hotelchat.sqlite3')
    destination.mkdir(parents=True,exist_ok=True,mode=0o700)
    dbpath = destination/'hotelchat.sqlite3'
    fd = os.open(dbpath,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as file: file.write(database)
    with closing(sqlite3.connect(dbpath)) as db:
        if db.execute('PRAGMA quick_check').fetchone()[0]!='ok':
            raise ValueError('Die wiederhergestellte Datenbank konnte nicht geprüft werden.')
        with db:
            # Restoring an old backup must not revive revoked sessions or invites.
            for table in ('sessions','invites','resets'): db.execute('DELETE FROM '+table)
    keypath = destination/'HOTELCHAT_MASTER_KEY.txt'
    fd = os.open(keypath,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as file: file.write(vault['master'])
    return dbpath


if __name__=='__main__':
    import argparse
    import getpass
    parser = argparse.ArgumentParser(description='Verschlüsselte HotelChat-Sicherung in einen leeren Ordner wiederherstellen.')
    parser.add_argument('backup',type=Path)
    parser.add_argument('destination',type=Path)
    args = parser.parse_args()
    restored = restore_export(args.backup.read_bytes(),getpass.getpass('Sicherungspasswort: '),args.destination)
    print('Sicherung geprüft und wiederhergestellt:',restored)
    print('Hauptschlüssel aus HOTELCHAT_MASTER_KEY.txt direkt in der geschützten Serverumgebung setzen. Nicht im Chat teilen.')
