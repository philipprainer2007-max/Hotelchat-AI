"""Persistent accounts, tenant permissions, sessions and atomic usage limits."""
import hashlib
import json
import os
import secrets
import sqlite3
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from werkzeug.security import generate_password_hash, check_password_hash


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript('''
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS users(
                    id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL, role TEXT NOT NULL, hotel_id TEXT,
                    disabled INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS sessions(
                    token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                    csrf TEXT NOT NULL, expires REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS hotels(
                    id TEXT PRIMARY KEY, profile TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1);
                CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS invites(
                    token_hash TEXT PRIMARY KEY, email TEXT NOT NULL, hotel_id TEXT NOT NULL,
                    expires REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS resets(
                    token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS rates(
                    key TEXT NOT NULL, window INTEGER NOT NULL, count INTEGER NOT NULL,
                    PRIMARY KEY(key,window));
                CREATE TABLE IF NOT EXISTS usage(
                    id TEXT PRIMARY KEY, hotel_id TEXT NOT NULL, day TEXT NOT NULL,
                    month TEXT NOT NULL, amount REAL NOT NULL, state TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS usage_day ON usage(day,hotel_id);
                CREATE INDEX IF NOT EXISTS usage_month ON usage(month);
            ''')
        os.chmod(self.path,0o600)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=20)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    @contextmanager
    def transaction(self):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            yield db

    def setting(self, key, default=None):
        with self.connect() as db:
            row = db.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def set_setting(self, key, value):
        with self.connect() as db:
            db.execute('INSERT OR REPLACE INTO settings VALUES (?,?)', (key, json.dumps(value)))

    def user_count(self):
        with self.connect() as db:
            return db.execute('SELECT COUNT(*) FROM users').fetchone()[0]

    def bootstrap(self, email, password):
        hashed = generate_password_hash(password, method='scrypt')
        with self.transaction() as db:
            if db.execute('SELECT 1 FROM users').fetchone():
                raise ValueError('Die Ersteinrichtung ist bereits abgeschlossen.')
            uid = str(uuid.uuid4())
            db.execute('INSERT INTO users VALUES (?,?,?,?,?,0)', (uid,email,hashed,'owner',None))
        return uid

    def login(self, email, password):
        with self.connect() as db:
            row = db.execute('SELECT * FROM users WHERE email=? AND disabled=0', (email,)).fetchone()
        # Keep the expensive password check for unknown accounts as well.
        encoded = row['password'] if row else generate_password_hash('unknown-account', method='scrypt')
        valid = check_password_hash(encoded, password)
        return row['id'] if row and valid else None

    def session(self, token):
        with self.connect() as db:
            row = db.execute('''SELECT users.*, sessions.csrf, sessions.expires
                FROM sessions JOIN users ON users.id=sessions.user_id
                WHERE token_hash=? AND expires>? AND disabled=0''', (digest(token),time.time())).fetchone()
        return dict(row) if row else None

    def new_session(self, uid):
        token, csrf = secrets.token_urlsafe(40), secrets.token_urlsafe(32)
        with self.connect() as db:
            db.execute('DELETE FROM sessions WHERE expires<?', (time.time(),))
            db.execute('INSERT INTO sessions VALUES (?,?,?,?)', (digest(token),uid,csrf,time.time()+43200))
        return token

    def logout(self, token):
        with self.connect() as db:
            db.execute('DELETE FROM sessions WHERE token_hash=?', (digest(token),))

    def hotels(self, user):
        with self.connect() as db:
            rows = db.execute('SELECT profile FROM hotels' + ('' if user['role']=='owner' else ' WHERE id=?'),
                              () if user['role']=='owner' else (user['hotel_id'],)).fetchall()
        return [json.loads(r[0]) for r in rows]

    def hotel(self, hid, user=None):
        if user and user['role']!='owner' and user['hotel_id']!=hid:
            return None
        with self.connect() as db:
            row = db.execute('SELECT profile,revision FROM hotels WHERE id=?', (hid,)).fetchone()
        if not row:
            return None
        return {**json.loads(row[0]), 'revision': row[1]}

    def save_hotel(self, hotel, expected=None):
        with self.transaction() as db:
            row = db.execute('SELECT revision FROM hotels WHERE id=?', (hotel['id'],)).fetchone()
            if row:
                if expected != row[0]:
                    raise ValueError('Das Hotel wurde inzwischen geändert. Bitte neu laden.')
                revision = row[0]+1
                db.execute('UPDATE hotels SET profile=?,revision=? WHERE id=?',
                           (json.dumps(hotel,ensure_ascii=False),revision,hotel['id']))
            else:
                revision = 1
                db.execute('INSERT INTO hotels VALUES (?,?,1)', (hotel['id'],json.dumps(hotel,ensure_ascii=False)))
        return {**hotel,'revision':revision}

    def invite(self, email, hid):
        token = secrets.token_urlsafe(40)
        with self.connect() as db:
            # One outstanding invitation per email; replacing it revokes the old link.
            db.execute('DELETE FROM invites WHERE email=? OR expires<?', (email,time.time()))
            db.execute('INSERT INTO invites VALUES (?,?,?,?)', (digest(token),email,hid,time.time()+172800))
        return token

    def accept(self, token, password):
        hashed = generate_password_hash(password, method='scrypt')
        with self.transaction() as db:
            row = db.execute('SELECT * FROM invites WHERE token_hash=? AND expires>?',
                             (digest(token),time.time())).fetchone()
            if not row:
                raise ValueError('Dieser Einladungslink ist ungültig oder abgelaufen.')
            if db.execute('SELECT 1 FROM users WHERE email=?', (row['email'],)).fetchone():
                raise ValueError('Für diese E-Mail besteht bereits ein Zugang.')
            uid = str(uuid.uuid4())
            db.execute('INSERT INTO users VALUES (?,?,?,?,?,0)', (uid,row['email'],hashed,'hotel',row['hotel_id']))
            db.execute('DELETE FROM invites WHERE token_hash=?', (digest(token),))
        return uid

    def reset_link(self, uid):
        token = secrets.token_urlsafe(40)
        with self.connect() as db:
            db.execute('DELETE FROM resets WHERE user_id=? OR expires<?',(uid,time.time()))
            db.execute('INSERT INTO resets VALUES (?,?,?)',(digest(token),uid,time.time()+3600))
        return token

    def reset_password(self, token, password):
        hashed = generate_password_hash(password,method='scrypt')
        with self.transaction() as db:
            row = db.execute('SELECT user_id FROM resets WHERE token_hash=? AND expires>?',(digest(token),time.time())).fetchone()
            if not row: raise ValueError('Dieser Rücksetzlink ist ungültig oder abgelaufen.')
            db.execute('UPDATE users SET password=? WHERE id=? AND disabled=0',(hashed,row[0]))
            db.execute('DELETE FROM sessions WHERE user_id=?',(row[0],))
            db.execute('DELETE FROM resets WHERE user_id=?',(row[0],))
        return row[0]

    def rate(self, key, limit, seconds=60):
        now = int(time.time())
        window = now//seconds*seconds
        with self.transaction() as db:
            db.execute('DELETE FROM rates WHERE window<?', (now-86400,))
            row = db.execute('SELECT count FROM rates WHERE key=? AND window=?', (key,window)).fetchone()
            if row and row[0]>=limit:
                return False
            db.execute('''INSERT INTO rates VALUES (?,?,1)
                ON CONFLICT(key,window) DO UPDATE SET count=count+1''', (key,window))
        return True

    def reserve(self, hid, amount, limits):
        now = datetime.now(timezone.utc)
        day, month = now.strftime('%Y-%m-%d'), now.strftime('%Y-%m')
        rid = str(uuid.uuid4())
        with self.transaction() as db:
            checks = [
                ('SELECT COALESCE(SUM(amount),0) FROM usage WHERE day=?', (day,),limits['daily']),
                ('SELECT COALESCE(SUM(amount),0) FROM usage WHERE month=?', (month,),limits['monthly']),
                ('SELECT COALESCE(SUM(amount),0) FROM usage WHERE day=? AND hotel_id=?', (day,hid),limits['hotelDaily'])]
            for sql, params, maximum in checks:
                if db.execute(sql,params).fetchone()[0]+amount>maximum:
                    raise ValueError('Das eingestellte KI-Limit ist erreicht. Bitte wenden Sie sich an die Rezeption.')
            db.execute('INSERT INTO usage VALUES (?,?,?,?,?,?)', (rid,hid,day,month,amount,'reserved'))
        return rid

    def settle(self, rid, cost):
        # No usage returned after a timeout? Keep the full reservation.
        with self.connect() as db:
            db.execute("UPDATE usage SET amount=?,state='estimated' WHERE id=?", (cost,rid))

    def totals(self):
        now = datetime.now(timezone.utc)
        with self.connect() as db:
            day = db.execute('SELECT COALESCE(SUM(amount),0) FROM usage WHERE day=?', (now.strftime('%Y-%m-%d'),)).fetchone()[0]
            month = db.execute('SELECT COALESCE(SUM(amount),0) FROM usage WHERE month=?', (now.strftime('%Y-%m'),)).fetchone()[0]
        return {'today':round(day,6),'month':round(month,6)}
