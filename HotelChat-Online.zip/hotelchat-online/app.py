"""Online HotelChat service. Local review server remains a separate application."""
import base64
import hashlib
import hmac
import json
import math
import os
import re
import secrets
import threading
import uuid
from functools import wraps
from pathlib import Path
from urllib.parse import urlsplit

from cryptography.fernet import Fernet, InvalidToken
from flask import Flask, Response, g, jsonify, redirect, render_template, request, send_file
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from werkzeug.exceptions import HTTPException
from werkzeug.middleware.proxy_fix import ProxyFix

import knowledge
from importer import crawl
from store import Store, digest

ROOT = Path(__file__).resolve().parent
FACTS = ('checkin','breakfast','directions','contact','other')
PUBLIC_FIELDS = ('id','name','color','position','round','label','greeting','logo','bookingUrl')
DEFAULT_LIMITS = {'daily':2.0,'monthly':20.0,'hotelDaily':1.0}


def origin(value):
    try:
        parsed = urlsplit(value)
        if parsed.scheme not in ('https','http') or not parsed.hostname or parsed.username or parsed.password:
            return None
        if parsed.path not in ('','/') or parsed.query or parsed.fragment:
            return None
        if parsed.scheme=='http' and parsed.hostname not in ('127.0.0.1','localhost'):
            return None
        return parsed.scheme+'://'+parsed.netloc.lower()
    except (ValueError,TypeError):
        return None


def https_url(value, optional=True):
    if not value and optional:
        return ''
    p = urlsplit(str(value))
    if p.scheme!='https' or not p.hostname or p.username or p.password or len(value)>2048:
        raise ValueError('Bitte einen vollständigen HTTPS-Link eingeben.')
    return value


def valid_email(value):
    value = str(value).strip().lower()
    if len(value)>254 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',value):
        raise ValueError('Bitte eine gültige E-Mail-Adresse eingeben.')
    return value


def password(value):
    if not isinstance(value,str) or not 12<=len(value)<=256:
        raise ValueError('Bitte ein Passwort mit mindestens 12 und höchstens 256 Zeichen wählen.')
    return value


def profile(raw, previous=None):
    old = previous or {}
    h = {'id':old.get('id','hotel-'+str(uuid.uuid4())),
         'demoKey':old.get('demoKey',secrets.token_urlsafe(32))}
    for key, size, default in [('name',150,'Neues Hotel'),('city',150,''),('greeting',1000,'Willkommen! Wie kann ich Ihnen helfen?'),('label',60,'Fragen Sie uns')]:
        value = raw.get(key,old.get(key,default))
        if not isinstance(value,str):
            raise ValueError('Ungültige Hotelangabe: '+key)
        h[key] = value.strip()[:size]
    if not h['name']:
        raise ValueError('Bitte einen Hotelnamen eingeben.')
    h['status'] = raw.get('status',old.get('status','draft'))
    if h['status'] not in ('draft','ready','paused'):
        raise ValueError('Ungültiger Status.')
    h['color'] = raw.get('color',old.get('color','#284c40'))
    if not isinstance(h['color'],str) or not re.fullmatch(r'#[a-fA-F0-9]{6}',h['color']):
        raise ValueError('Ungültige Farbe.')
    h['position'] = 'left' if raw.get('position',old.get('position'))=='left' else 'right'
    h['round'] = raw.get('round',old.get('round',True)) is not False
    for key in ('website','bookingUrl','privacyUrl'):
        h[key] = https_url(raw.get(key,old.get(key,'')))
    h['logo'] = raw.get('logo',old.get('logo',''))
    if not isinstance(h['logo'],str) or len(h['logo'])>2800000 or (h['logo'] and not re.fullmatch(r'data:image/(?:png|jpeg|webp|gif);base64,[A-Za-z0-9+/=\s]+',h['logo'])):
        raise ValueError('Bitte ein PNG-, JPG-, WebP- oder GIF-Logo bis 2 MB verwenden.')
    values = raw.get('facts',old.get('facts',{}))
    if not isinstance(values,dict) or any(not isinstance(values.get(k,''),str) for k in FACTS):
        raise ValueError('Ungültige Hotelinformationen.')
    h['facts'] = {k:values.get(k,'')[:5000] for k in FACTS}
    allowed = raw.get('allowedOrigins',old.get('allowedOrigins',[]))
    if not isinstance(allowed,list) or len(allowed)>10:
        raise ValueError('Bitte höchstens zehn Website-Adressen für den Einbau angeben.')
    h['allowedOrigins'] = []
    for value in allowed:
        safe = origin(value)
        if not safe or not safe.startswith('https:'):
            raise ValueError('Einbau-Adressen müssen HTTPS-Adressen ohne Unterseiten sein.')
        if safe not in h['allowedOrigins']:
            h['allowedOrigins'].append(safe)
    for key in ('privacyReviewed','answersReviewed','contractsReviewed'):
        h[key] = raw.get(key,old.get(key,False)) is True
    return h


def create_app(config=None):
    app = Flask(__name__)
    app.config.update(MAX_CONTENT_LENGTH=3200000, TESTING=False,
                      DATA_DIR=os.environ.get('HOTELCHAT_DATA_DIR',str(ROOT/'data')),
                      PUBLIC_URL=os.environ.get('PUBLIC_URL',''),
                      MASTER_KEY=os.environ.get('HOTELCHAT_MASTER_KEY',''),
                      BOOTSTRAP_TOKEN=os.environ.get('HOTELCHAT_BOOTSTRAP_TOKEN',''),
                      LOCAL_DEV=os.environ.get('HOTELCHAT_LOCAL_DEV')=='1',
                      TRUST_PROXY=os.environ.get('HOTELCHAT_TRUST_PROXY')=='1',
                      MODEL=os.environ.get('ANTHROPIC_MODEL',knowledge.DEFAULT_MODEL))
    if config:
        app.config.update(config)
    public = origin(app.config['PUBLIC_URL'])
    if not public or (not public.startswith('https:') and not app.config['LOCAL_DEV']):
        raise RuntimeError('PUBLIC_URL muss die öffentliche HTTPS-Adresse der App sein.')
    master = app.config['MASTER_KEY']
    if not isinstance(master,str) or len(master)<32:
        raise RuntimeError('HOTELCHAT_MASTER_KEY mit mindestens 32 zufälligen Zeichen fehlt.')
    if app.config['TRUST_PROXY']:
        # Only enable behind Render's trusted reverse proxy, never on a bare port.
        app.wsgi_app = ProxyFix(app.wsgi_app,x_for=1,x_proto=1)
    # Derive purpose-specific keys; the master remains outside the database.
    secret = hashlib.sha256(master.encode()).digest()
    cipher = Fernet(base64.urlsafe_b64encode(hmac.new(secret,b'hotelchat-vault',hashlib.sha256).digest()))
    signer = URLSafeTimedSerializer(hmac.new(secret,b'hotelchat-guest',hashlib.sha256).hexdigest())
    db = Store(Path(app.config['DATA_DIR'])/'hotelchat.sqlite3')
    sources = knowledge.SourceStore(db.path)
    app.extensions.update(store=db, sources=sources)
    if not app.config['TESTING']:
        from backup import backup_loop
        threading.Thread(target=backup_loop,args=(app.config['DATA_DIR'],),daemon=True).start()
    slots = threading.BoundedSemaphore(3)
    imports = threading.Lock()

    def ip_key():
        # No raw visitor IPs or questions in application storage.
        return hmac.new(secret,('ip:'+str(request.remote_addr)).encode(),hashlib.sha256).hexdigest()

    def data():
        if not request.is_json:
            raise ValueError('JSON-Anfrage erforderlich.')
        value = request.get_json(silent=True)
        if not isinstance(value,dict):
            raise ValueError('Ungültige Anfrage.')
        return value

    def owner(fn):
        @wraps(fn)
        def check(*args,**kwargs):
            if not g.user or g.user['role']!='owner':
                return jsonify(error='Nur für die Betreiberverwaltung freigegeben.'),403
            return fn(*args,**kwargs)
        return check

    def hotel_access(hid):
        h = db.hotel(hid,g.user)
        if not h:
            raise LookupError('Hotel nicht gefunden oder kein Zugriff.')
        return h

    def api_key():
        if db.setting('aiDisabled',False): return ''
        saved = db.setting('anthropicKey')
        if saved:
            try:
                return cipher.decrypt(saved.encode()).decode()
            except InvalidToken:
                raise RuntimeError('Gespeicherter Schlüssel konnte nicht geöffnet werden.')
        return os.environ.get('ANTHROPIC_API_KEY','')

    def operator_ready():
        op = db.setting('operator',{})
        return all(isinstance(op.get(k),str) and op[k].strip() for k in ('name','address','email'))

    def readiness(h):
        summary = sources.summary(h['id'],h['website'])
        return {
            'operator':operator_ready(), 'privacy':bool(h.get('privacyUrl')) and h['privacyReviewed'],
            'contracts':h['contractsReviewed'], 'answers':h['answersReviewed'],
            'sources':summary['available'], 'ai':bool(api_key()),
            'websites':bool(h['allowedOrigins'])}

    def require_public(h):
        if not all(readiness(h).values()):
            raise PermissionError('Dieser Chat ist noch nicht für Hotelgäste freigegeben.')

    @app.before_request
    def security():
        # Trust the configured external origin, never a forwarded Host header.
        if request.host != urlsplit(public).netloc:
            return jsonify(error='Unbekannte App-Adresse.'),400
        g.user = db.session(request.cookies.get('hotelchat_session',''))
        g.parent_origin = public
        is_api = request.path.startswith('/api/')
        is_public = request.path.startswith('/api/public/')
        if is_api and not is_public:
            exempt = request.path in ('/api/login','/api/setup','/api/accept','/api/reset','/api/state')
            if not exempt and not g.user:
                return jsonify(error='Bitte anmelden.'),401
            if request.method not in ('GET','HEAD','OPTIONS'):
                if request.headers.get('Origin')!=public:
                    return jsonify(error='Ungültige Website-Herkunft.'),403
                if g.user and not hmac.compare_digest(request.headers.get('X-HotelChat-Token',''),g.user['csrf']):
                    return jsonify(error='Bitte die Verwaltung neu laden.'),403
        if request.method in ('POST','PUT','DELETE') and not is_public and not db.rate('write:'+ip_key(),120):
            return jsonify(error='Zu viele Anfragen. Bitte kurz warten.'),429

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'no-referrer'
        response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
        response.headers['Cache-Control'] = 'no-store'
        ancestors = "'self'"
        if request.path.startswith('/widget/'):
            h = db.hotel(request.path.rsplit('/',1)[-1])
            if h:
                ancestors += ' '+' '.join(h['allowedOrigins'])
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'self'; object-src 'none'; frame-ancestors "+ancestors
        if not request.path.startswith('/widget/'):
            response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        if public.startswith('https:'):
            response.headers['Strict-Transport-Security'] = 'max-age=31536000'
        return response

    @app.errorhandler(Exception)
    def errors(error):
        if isinstance(error,HTTPException):
            status = error.code
            message = 'Anfrage zu groß.' if status==413 else 'Anfrage konnte nicht verarbeitet werden.'
        elif isinstance(error,ValueError): status,message = 400,str(error)
        elif isinstance(error,LookupError): status,message = 404,str(error)
        elif isinstance(error,PermissionError): status,message = 403,str(error)
        else:
            # Never log request bodies, visitor histories or provider credentials.
            app.logger.error('Request failed: %s',type(error).__name__)
            status,message = 500,'Die Anfrage konnte nicht abgeschlossen werden. Bitte erneut versuchen.'
        if request.path.startswith('/api/'):
            return jsonify(error=message),status
        return render_template('message.html',message=message),status

    @app.get('/health')
    def health():
        with db.connect() as conn:
            conn.execute('SELECT 1')
        return jsonify(status='ok')

    @app.get('/')
    def index():
        if not db.user_count(): return redirect('/setup')
        return render_template('admin.html') if g.user else redirect('/login')

    @app.get('/login')
    @app.get('/setup')
    @app.get('/accept')
    @app.get('/reset')
    def auth_page():
        return render_template('auth.html',mode=request.path[1:])

    def signed_in(uid):
        token = db.new_session(uid)
        result = jsonify(ok=True)
        result.set_cookie('hotelchat_session',token,httponly=True,secure=not app.config['LOCAL_DEV'],
                          samesite='Lax',max_age=43200,path='/')
        return result

    @app.post('/api/setup')
    def setup():
        raw = data()
        expected = app.config['BOOTSTRAP_TOKEN']
        if not expected or not hmac.compare_digest(str(raw.get('token','')),expected):
            return jsonify(error='Für die Ersteinrichtung wird der geschützte Einrichtungslink benötigt.'),403
        return signed_in(db.bootstrap(valid_email(raw.get('email','')),password(raw.get('password'))))

    @app.post('/api/login')
    def login():
        raw = data()
        if not db.rate('login:'+ip_key(),8,900):
            return jsonify(error='Zu viele Anmeldeversuche. Bitte in 15 Minuten erneut versuchen.'),429
        email = valid_email(raw.get('email',''))
        pw = raw.get('password','')
        if not isinstance(pw,str) or len(pw)>256:
            raise ValueError('Ungültige Zugangsdaten.')
        uid = db.login(email,pw)
        if not uid: return jsonify(error='E-Mail oder Passwort ist nicht korrekt.'),401
        return signed_in(uid)

    @app.post('/api/accept')
    def accept():
        raw = data()
        if not db.rate('accept:'+ip_key(),8,900):
            return jsonify(error='Zu viele Versuche. Bitte später erneut versuchen.'),429
        return signed_in(db.accept(str(raw.get('token',''))[:200],password(raw.get('password'))))

    @app.post('/api/reset')
    def reset_password():
        raw = data()
        if not db.rate('reset:'+ip_key(),8,900):
            return jsonify(error='Zu viele Versuche. Bitte später erneut versuchen.'),429
        return signed_in(db.reset_password(str(raw.get('token',''))[:200],password(raw.get('password'))))

    @app.post('/api/logout')
    def logout():
        db.logout(request.cookies.get('hotelchat_session',''))
        response = jsonify(ok=True)
        response.delete_cookie('hotelchat_session',path='/')
        return response

    @app.get('/api/state')
    def state():
        if not g.user:
            return jsonify(authenticated=False,setupRequired=not db.user_count())
        result = {'authenticated':True,'role':g.user['role'],'email':g.user['email'],'token':g.user['csrf'],
                  'hotels':db.hotels(g.user),'aiReady':bool(api_key()),'publicUrl':public}
        # Attach server revisions, never rely on a browser's ownership claim.
        result['hotels'] = [db.hotel(h['id'],g.user) for h in result['hotels']]
        result['readiness'] = {h['id']:readiness(h) for h in result['hotels']}
        if g.user['role']=='owner':
            result.update(operator=db.setting('operator',{}),limits=db.setting('limits',DEFAULT_LIMITS),usage=db.totals())
            with db.connect() as conn:
                result['users'] = [dict(r) for r in conn.execute('SELECT id,email,hotel_id,disabled FROM users WHERE role=?',('hotel',))]
        return jsonify(result)

    @app.post('/api/hotels')
    @owner
    def add_hotel():
        h = db.save_hotel(profile(data()))
        return jsonify(hotel=h)

    @app.put('/api/hotels/<hid>')
    def update_hotel(hid):
        current = hotel_access(hid)
        raw = data()
        h = profile(raw,current)
        if g.user['role']!='owner':
            # Public approval and allowed websites belong to the platform owner.
            for k in ('allowedOrigins','privacyReviewed','answersReviewed','contractsReviewed','status'):
                h[k] = current[k]
        if raw.get('rotateDemo') and g.user['role']=='owner':
            h['demoKey'] = secrets.token_urlsafe(32)
        return jsonify(hotel=db.save_hotel(h,raw.get('revision')))

    @app.post('/api/import')
    def import_site():
        raw = data()
        h = hotel_access(raw.get('hotelId',''))
        if not h['website']: raise ValueError('Bitte zuerst die Hotelwebsite speichern.')
        if not db.rate('import:'+h['id'],4,3600):
            return jsonify(error='Dieses Hotel wurde bereits mehrfach eingelesen. Bitte später erneut versuchen.'),429
        if not imports.acquire(blocking=False):
            return jsonify(error='Eine Website wird gerade eingelesen. Bitte kurz warten.'),429
        try:
            result = crawl(h['website'],h['id'])
            sources.save(result)
        finally:
            imports.release()
        return jsonify(pages=len(result.get('documents',[])),importedAt=result['scannedAt'])

    @app.post('/api/settings')
    @owner
    def settings():
        raw = data()
        if 'operator' in raw:
            op = raw['operator']
            if not isinstance(op,dict): raise ValueError('Ungültige Betreiberangaben.')
            cleaned = {k:str(op.get(k,''))[:1000].strip() for k in ('name','address','email')}
            if cleaned['email']: cleaned['email'] = valid_email(cleaned['email'])
            db.set_setting('operator',cleaned)
        if 'limits' in raw:
            values = raw['limits']
            if not isinstance(values,dict): raise ValueError('Ungültige Kostenlimits.')
            limits = {}
            for k in DEFAULT_LIMITS:
                v = values.get(k)
                if type(v) not in (int,float) or not math.isfinite(v) or not 0<=v<=1000:
                    raise ValueError('Kostenlimits müssen zwischen 0 und 1000 US-Dollar liegen.')
                limits[k] = float(v)
            db.set_setting('limits',limits)
        return jsonify(ok=True)

    @app.post('/api/ai-settings')
    @owner
    def ai_settings():
        raw = data()
        key = raw.get('key')
        if not isinstance(key,str) or (key and (not key.startswith('sk-ant-') or len(key)>500)):
            raise ValueError('Bitte einen gültigen Anthropic-API-Schlüssel eingeben.')
        if not db.rate('ai-settings:'+g.user['id'],5,3600):
            return jsonify(error='Bitte die Verbindung später erneut prüfen.'),429
        if key:
            try: knowledge.validate_connection(key.strip(),app.config['MODEL'])
            except knowledge.ProviderError as exc: raise ValueError(str(exc))
            db.set_setting('anthropicKey',cipher.encrypt(key.strip().encode()).decode())
            db.set_setting('aiDisabled',False)
        else:
            db.set_setting('anthropicKey',None)
            db.set_setting('aiDisabled',True)
        return jsonify(aiReady=bool(api_key()))

    @app.post('/api/backup')
    @owner
    def backup_export():
        raw = data()
        if not db.rate('backup:'+g.user['id'],4,3600):
            return jsonify(error='Bitte die nächste Sicherung später erstellen.'),429
        from secure_backup import encrypted_export
        payload = encrypted_export(app.config['DATA_DIR'],app.config['MASTER_KEY'],raw.get('passphrase'))
        return Response(payload,mimetype='application/octet-stream',headers={
            'Content-Disposition':'attachment; filename="HotelChat-Sicherung.hotelchat"'})

    @app.post('/api/invites')
    @owner
    def invite():
        raw = data()
        h = hotel_access(raw.get('hotelId',''))
        email = valid_email(raw.get('email',''))
        token = db.invite(email,h['id'])
        # Token in fragment: never sent to proxy logs or Referrer headers.
        return jsonify(url=public+'/accept#'+token,expiresHours=48)

    @app.post('/api/users/<uid>/disable')
    @owner
    def disable_user(uid):
        with db.transaction() as conn:
            conn.execute("UPDATE users SET disabled=1 WHERE id=? AND role='hotel'",(uid,))
            conn.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
        return jsonify(ok=True)

    @app.post('/api/users/<uid>/reset')
    @owner
    def reset_user(uid):
        with db.connect() as conn:
            row = conn.execute("SELECT id FROM users WHERE id=? AND role='hotel' AND disabled=0",(uid,)).fetchone()
        if not row: raise LookupError('Hotelzugang nicht gefunden.')
        return jsonify(url=public+'/reset#'+db.reset_link(uid))

    def chat(h, raw):
        q = raw.get('question','')
        hist = raw.get('history',[])
        if not isinstance(q,str) or not q.strip() or len(q)>2000:
            raise ValueError('Bitte eine Frage mit bis zu 2000 Zeichen stellen.')
        if not isinstance(hist,list) or len(hist)>8 or any(not isinstance(x,dict) or x.get('role') not in ('user','assistant') or not isinstance(x.get('content'),str) or len(x['content'])>2000 for x in hist):
            raise ValueError('Ungültiger Gesprächsverlauf.')
        if not db.rate('chat-ip:'+ip_key(),20) or not db.rate('chat-hotel:'+h['id'],120):
            return jsonify(error='Zu viele Fragen. Bitte kurz warten.'),429
        if not slots.acquire(blocking=False):
            return jsonify(error='Der Concierge beantwortet gerade mehrere Fragen. Bitte kurz erneut versuchen.'),429
        try:
            key = api_key()
            if not key: raise ValueError('Der Concierge ist gerade nicht verfügbar. Bitte kontaktieren Sie die Rezeption.')
            def budgeted(payload, credential):
                # A conservative byte bound includes all documents, history and output.
                # Reject unsupported pricing policies instead of silently undercounting.
                if payload['model']!='claude-haiku-5-5':
                    raise ValueError('Für dieses Modell ist kein geprüftes Kostenlimit hinterlegt.')
                payload['max_tokens'] = 800
                size = len(json.dumps(payload,ensure_ascii=False).encode())
                if size>400000:
                    raise ValueError('Das eingelesene Hotelwissen ist zu groß. Bitte im Kontrollzentrum prüfen.')
                reserve = ((size+16000)*1.0+800*5.0)/1000000
                try: rid = db.reserve(h['id'],reserve,db.setting('limits',DEFAULT_LIMITS))
                except ValueError as exc: raise knowledge.ProviderError(str(exc))
                response = app.config.get('PROVIDER',knowledge.call_claude)(payload,credential)
                raw_usage = response.get('usage',{})
                if isinstance(raw_usage,dict) and all(type(raw_usage.get(k)) is int and raw_usage[k]>=0 for k in ('input_tokens','output_tokens')):
                    cost = knowledge.estimated_cost_usd(knowledge.usage_stats(response),payload['model'])
                    if cost is not None: db.settle(rid,cost)
                return response
            result = knowledge.answer(sources,h['id'],h['website'],h['name'],q,h['facts'],hist,
                                      key=key,model=app.config['MODEL'],provider=budgeted)
            # No prices, provider diagnostics, usage or model names in guest responses.
            return jsonify(hotelId=h['id'],text=result['text'],sources=result.get('sources',[]),
                           mode=result.get('mode','ai'),notice='KI-Concierge · Antworten aus Hotelinformationen')
        finally:
            slots.release()

    @app.post('/api/chat')
    def admin_chat():
        raw = data()
        return chat(hotel_access(raw.get('hotelId','')),raw)

    @app.get('/preview/<hid>')
    def preview(hid):
        if not g.user: return redirect('/login')
        h = hotel_access(hid)
        return render_template('guest.html',hotel=h,internal=True,parent=public)

    @app.get('/demo/<hid>/<demo_key>')
    def demo(hid,demo_key):
        h = db.hotel(hid)
        if not h or not hmac.compare_digest(h['demoKey'],demo_key):
            raise LookupError('Dieser Demo-Link ist ungültig.')
        require_public(h)
        if h['status']=='paused': raise PermissionError('Dieser Chat ist pausiert.')
        return render_template('guest.html',hotel=h,internal=False,parent=public,demo_key=demo_key)

    @app.get('/widget/<hid>')
    def widget(hid):
        h = db.hotel(hid)
        if not h: raise LookupError('Hotel nicht gefunden.')
        require_public(h)
        if h['status']!='ready': raise PermissionError('Dieser Chat ist noch nicht freigegeben.')
        parent = origin(request.args.get('parent',''))
        if parent not in h['allowedOrigins']: raise PermissionError('Diese Hotelwebsite ist nicht für den Chat freigegeben.')
        return render_template('guest.html',hotel=h,internal=False,parent=parent,demo_key='')

    @app.post('/api/public/start')
    def start_guest():
        if request.headers.get('Origin')!=public: raise PermissionError('Ungültige Website-Herkunft.')
        raw = data()
        h = db.hotel(str(raw.get('hotelId','')))
        if not h: raise LookupError('Hotel nicht gefunden.')
        require_public(h)
        parent = origin(raw.get('parent',''))
        demo_key = str(raw.get('demoKey',''))
        demo_allowed = parent==public and bool(demo_key) and hmac.compare_digest(h['demoKey'],demo_key)
        embedded = parent in h['allowedOrigins'] and h['status']=='ready'
        if h['status']=='paused' or not (demo_allowed or embedded): raise PermissionError('Dieser Chat ist nicht freigegeben.')
        if not db.rate('start:'+ip_key(),30): return jsonify(error='Bitte kurz warten.'),429
        token = signer.dumps({'hotel':h['id'],'version':h['revision'],'parent':parent,'demo':demo_allowed,'nonce':secrets.token_hex(16)},salt='guest')
        return jsonify(token=token,hotel={k:h[k] for k in PUBLIC_FIELDS})

    @app.get('/api/public/appearance/<hid>')
    def appearance(hid):
        h = db.hotel(hid)
        if not h: raise LookupError('Hotel nicht gefunden.')
        parent = request.headers.get('Origin','')
        if parent not in h['allowedOrigins'] or h['status']!='ready':
            raise PermissionError('Diese Hotelwebsite ist nicht freigegeben.')
        require_public(h)
        response = jsonify({k:h[k] for k in PUBLIC_FIELDS})
        response.headers['Access-Control-Allow-Origin'] = parent
        response.headers['Vary'] = 'Origin'
        return response

    @app.post('/api/public/chat')
    def public_chat():
        if request.headers.get('Origin')!=public: raise PermissionError('Ungültige Website-Herkunft.')
        raw = data()
        try: signed = signer.loads(str(raw.get('token','')),salt='guest',max_age=1800)
        except (BadSignature,SignatureExpired): return jsonify(error='Bitte den Chat schließen und erneut starten.'),401
        h = db.hotel(signed['hotel'])
        if not h or raw.get('hotelId')!=h['id'] or signed['version']!=h['revision']:
            raise PermissionError('Die Hotelinformationen wurden geändert. Bitte den Chat neu öffnen.')
        require_public(h)
        if h['status']=='paused' or (not signed['demo'] and (h['status']!='ready' or signed['parent'] not in h['allowedOrigins'])):
            raise PermissionError('Dieser Chat ist pausiert.')
        if not db.rate('guest:'+signed['nonce'],12): return jsonify(error='Bitte kurz warten.'),429
        return chat(h,raw)

    @app.get('/privacy/<hid>')
    def privacy(hid):
        h = db.hotel(hid)
        if not h: raise LookupError('Hotel nicht gefunden.')
        return render_template('privacy.html',hotel=h,operator=db.setting('operator',{}))

    @app.get('/embed.js')
    def embed():
        response = send_file(ROOT/'static'/'embed.js',mimetype='application/javascript')
        response.headers['Access-Control-Allow-Origin'] = '*'
        return response

    return app
