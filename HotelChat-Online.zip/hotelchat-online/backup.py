"""Create a consistent database backup; no master key is copied."""
import os
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

def create_backup(data,destination=None):
    data = Path(data)
    destination = Path(destination or data/'backups')
    destination.mkdir(parents=True,exist_ok=True)
    path = destination/('hotelchat-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.sqlite3')
    fd = os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    os.close(fd)
    with closing(sqlite3.connect(data/'hotelchat.sqlite3')) as source, closing(sqlite3.connect(path)) as target:
        source.backup(target)
        # A downloadable backup must stand alone without WAL/SHM sidecars.
        target.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        target.execute('PRAGMA journal_mode=DELETE')
        if target.execute('PRAGMA quick_check').fetchone()[0]!='ok':
            raise RuntimeError('Die Sicherung konnte nicht geprüft werden.')
    return path

def backup_loop(data):
    """Daily rolling backups on the persistent disk, not an off-site backup."""
    import threading
    import time
    wait = threading.Event()
    while True:
        try:
            directory = Path(data)/'backups'
            today = datetime.now(timezone.utc).strftime('%Y%m%d')
            if not directory.exists() or not list(directory.glob('hotelchat-'+today+'*.sqlite3')):
                create_backup(data)
            for old in directory.glob('hotelchat-*.sqlite3'):
                if old.stat().st_mtime<time.time()-7*86400:
                    old.unlink()
        except (OSError,sqlite3.Error,RuntimeError):
            # Report only a failure type; never filenames with private request data.
            import logging
            logging.getLogger('hotelchat').error('Database backup failed')
        wait.wait(3600)

if __name__=='__main__':
    root = Path(__file__).resolve().parent
    data = Path(os.environ.get('HOTELCHAT_DATA_DIR',str(root/'data')))
    print('Datenbanksicherung erstellt:',create_backup(data,os.environ.get('HOTELCHAT_BACKUP_DIR')))
