"""Bounded, same-site website importer. No model, API key or third-party packages."""
import html
import http.client
import ipaddress
import json
import re
import socket
import ssl
import time
import urllib.parse
import urllib.robotparser
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

AGENT = 'HotelChatImporter/1.0'
LIMIT = 2_000_000
CATEGORIES = {
    'checkin': r'check.?in|check.?out|eincheck|bezugsfertig|zimmer.{0,45}(?:ab \d|bis \d|freizu)|(?:ankunft|abreise|anreise).{0,30}(?:uhr|\d[.:]\d)',
    'breakfast': r'frühstück|fruehstueck|breakfast|colazione',
    'directions': r'anfahrt|parkplatz|parkplätze|tiefgarage|bahnhof|straße|strasse|\bweg \d|schlossweg|adresse|arrival|directions',
    'contact': r'kontakt|telefon|e.mail|contact|\+\d[\d ()/-]{7,}|[\w.+-]+@[\w.-]+\.[a-z]{2,}',
    'rooms': r'zimmer|suite|doppelbett|einzelbett|room|camera',
    'dining': r'restaurant|gourmet|halbpension|abendessen|küche|kulinar|dinner|cena',
    'wellness': r'wellness|sauna|schwimmbad|hallenbad|freibad|pool|massage|dampfbad|spa\b',
    'policies': r'haustier|\bhunde?\b|storno|kinder(?:menü|preise|ermäßigung)?\b|barrierefrei|rollstuhl|pets|cancellation',
    'other': r'wandern|wanderung|aktiv|guest.pass|w.lan|wifi|kostenlos|inklusive|ausstattung|angebot',
}
SKIP_PATH = re.compile(r'\.(pdf|jpe?g|png|webp|gif|svg|mp4|zip|css|js|woff2?|ico)$|/(login|admin|checkout|cart|privacy|datenschutz|cookies)(/|$)', re.I)

def checked_url(value):
    if not isinstance(value, str) or len(value) > 2048:
        raise ValueError('Bitte einen gültigen Website-Link eingeben.')
    value = value.strip()
    if '://' not in value:
        value = 'https://' + value
    p = urllib.parse.urlsplit(value)
    if p.scheme != 'https' or not p.hostname or p.username or p.password or p.port not in (None,443):
        raise ValueError('Bitte eine öffentliche HTTPS-Website ohne Zugangsdaten verwenden.')
    hostname = p.hostname.rstrip('.').encode('idna').decode('ascii').lower()
    if ':' in hostname or '.' not in hostname or hostname.endswith(('.local','.localhost','.internal')):
        raise ValueError('Lokale Netzwerkadressen können nicht eingelesen werden.')
    try:
        if not ipaddress.ip_address(hostname).is_global:
            raise ValueError('Lokale Netzwerkadressen können nicht eingelesen werden.')
    except ValueError as exc:
        if 'Lokale' in str(exc):
            raise
    # Query parameters are discarded: no search, booking-session or calendar crawls.
    return urllib.parse.urlunsplit(('https', hostname, p.path or '/', '', ''))

def same_site(a, b):
    return urllib.parse.urlsplit(a).hostname.removeprefix('www.') == urllib.parse.urlsplit(b).hostname.removeprefix('www.')

def public_addresses(host):
    addresses = list(dict.fromkeys(row[4][0] for row in socket.getaddrinfo(host,443,type=socket.SOCK_STREAM)))
    if not addresses or any(not ipaddress.ip_address(address).is_global for address in addresses):
        raise ValueError('Die Website verweist auf eine nicht öffentliche Netzwerkadresse.')
    return addresses

class PinnedHTTPS(http.client.HTTPSConnection):
    def __init__(self, host, address, timeout):
        super().__init__(host, timeout=timeout, context=ssl.create_default_context())
        self.address = address

    def connect(self):
        sock = socket.create_connection((self.address,443),self.timeout)
        try:
            self.sock = self._context.wrap_socket(sock,server_hostname=self.host)
        except BaseException:
            sock.close()
            raise

def fetch_page(url, site, timeout=8, redirects=3):
    url=checked_url(url)
    if not same_site(url,site):
        raise ValueError('Externe Websites werden nicht automatisch verfolgt.')
    p=urllib.parse.urlsplit(url)
    addresses=public_addresses(p.hostname)
    connection=PinnedHTTPS(p.hostname,addresses[0],timeout)
    try:
        connection.request('GET',p.path or '/',headers={'User-Agent':AGENT,'Accept':'text/html,application/xhtml+xml,application/xml,text/plain;q=0.8','Accept-Encoding':'identity'})
        response=connection.getresponse()
        if response.status in (301,302,303,307,308):
            if redirects <= 0:
                raise ValueError('Zu viele Weiterleitungen.')
            return fetch_page(urllib.parse.urljoin(url,response.getheader('Location','')),site,timeout,redirects-1)
        raw=response.read(LIMIT+1)
        if len(raw)>LIMIT:
            raise ValueError('Diese Unterseite ist zu groß und wurde ausgelassen.')
        if response.getheader('Content-Encoding','identity').lower() not in ('identity',''):
            raise ValueError('Komprimiertes Seitenformat konnte nicht verarbeitet werden.')
        content_type=response.getheader('Content-Type','').lower()
        encoding=re.search(r'charset=["\']?([\w-]+)',content_type)
        try:
            text=raw.decode(encoding.group(1) if encoding else 'utf-8',errors='replace')
        except LookupError:
            text=raw.decode('utf-8',errors='replace')
        return {'url':url,'status':response.status,'type':content_type,'text':text}
    finally:
        connection.close()

class PageParser(HTMLParser):
    blocks={'p','div','li','h1','h2','h3','h4','h5','h6','section','article','address','tr','br'}
    ignored={'script','style','noscript','svg','nav','form','button','select','textarea','template'}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links=[];self.text=[];self.current=[];self.title=[];self.in_title=False;self.site_name=''
        self.depth=0;self.script=None;self.scripts=[];self.heading='';self.heading_tag=None;self.heading_text=[]

    def flush(self):
        text=re.sub(r'\s+',' ',' '.join(self.current)).strip();self.current=[]
        if len(text)>=12:
            for start in range(0,len(text),1400):
                part=text[start:start+1400].strip()
                if len(part)>=12:self.text.append((self.heading,part))

    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='meta' and a.get('property','').lower()=='og:site_name':self.site_name=a.get('content','')[:150]
        if tag=='a' and a.get('href'):self.links.append(a['href'])
        if tag=='title':self.in_title=True
        if tag=='script' and a.get('type','').lower()=='application/ld+json':self.script=[]
        if self.depth:
            if tag in self.ignored:self.depth+=1
            return
        if tag in self.ignored:self.flush();self.depth=1;return
        if tag in self.blocks:self.flush()
        if tag in ('h1','h2','h3','h4'):self.heading_tag=tag;self.heading_text=[]

    def handle_endtag(self,tag):
        if tag=='script' and self.script is not None:
            self.scripts.append(''.join(self.script));self.script=None
        if tag=='title':self.in_title=False
        if self.depth:
            if tag in self.ignored:self.depth=max(0,self.depth-1)
            return
        if tag==self.heading_tag:
            self.heading=re.sub(r'\s+',' ',' '.join(self.heading_text)).strip();self.heading_tag=None;self.current=[]
        elif tag in self.blocks:self.flush()

    def handle_data(self,data):
        if self.script is not None:self.script.append(data)
        if self.in_title:self.title.append(data);return
        if self.depth:return
        if self.heading_tag:self.heading_text.append(data)
        self.current.append(data)

    def finish(self):
        self.flush()
        self.title=re.sub(r'\s+',' ',' '.join(self.title)).strip()[:250]
        return self

def parse_page(text):
    parser=PageParser();parser.feed(text);return parser.finish()

def structured_blocks(parser):
    result=[]
    def walk(data):
        if isinstance(data,list):
            for value in data:walk(value)
        elif isinstance(data,dict):
            kind=data.get('@type',[]);kind=[kind] if isinstance(kind,str) else kind
            if any(k in ('Hotel','LodgingBusiness','Resort','BedAndBreakfast','Motel') for k in kind):
                for key,category,label in [('checkinTime','checkin','Check-in'),('checkin','checkin','Check-in'),('checkoutTime','checkin','Check-out'),('telephone','contact','Telefon'),('email','contact','E-Mail')]:
                    if isinstance(data.get(key),str):result.append((category,label+': '+data[key][:500]))
                address=data.get('address',{})
                if isinstance(address,dict):
                    parts=[address.get(k) for k in ['streetAddress','postalCode','addressLocality','addressRegion']]
                    if any(isinstance(x,str) for x in parts):result.append(('directions','Adresse: '+', '.join(x for x in parts if isinstance(x,str))))
            if '@graph' in data:walk(data['@graph'])
    for script in parser.scripts:
        try:walk(json.loads(script))
        except (ValueError,TypeError):pass
    # Contact links are useful even when placed in navigation or the footer.
    for link in parser.links:
        if link.startswith(('tel:','mailto:')):
            result.append(('contact',('Telefon: ' if link.startswith('tel:') else 'E-Mail: ')+urllib.parse.unquote(link.split(':',1)[1].split('?')[0])[:300]))
    return result

def candidates_for(page):
    parser=parse_page(page['text']);rows=[]
    for heading,text in parser.text:
        if re.search(r'cookie|newsletter|marketing|datenschutzerklärung|personenbezogene',text,re.I):continue
        for category,pattern in CATEGORIES.items():
            if re.search(pattern,text,re.I):rows.append({'category':category,'text':text,'heading':heading[:200]})
    for category,text in structured_blocks(parser):rows.append({'category':category,'text':text,'heading':'Strukturierte Kontakt- und Hoteldaten'})
    for row in rows:row.update(url=page['url'],title=parser.title)
    return parser,rows

def priority(url):
    return sum(bool(re.search(pattern,url,re.I)) for pattern in [r'faq|gut.zu.wissen|wissenswert|info|kontakt|contact|agbs',r'frueh|breakfast|gourmet|restaurant|anreise|anfahrt|arrival',r'wellness|sauna|pool|zimmer|suite|room|preis|inklusi|storno|hotel'])

def crawl(website, hotel_id, max_pages=20, fetcher=fetch_page, budget=85):
    start=checked_url(website);deadline=time.monotonic()+budget
    robots=fetcher(urllib.parse.urljoin(start,'/robots.txt'),start)
    if robots['status'] in (401,403):raise ValueError('Die Website erlaubt kein automatisches Einlesen.')
    if robots['status']>=500:raise ValueError('Die Website ist gerade nicht zuverlässig erreichbar. Bitte später erneut versuchen.')
    rules=urllib.robotparser.RobotFileParser();rules.set_url(urllib.parse.urljoin(start,'/robots.txt'))
    rules.parse(robots['text'].splitlines() if robots['status']==200 else [])
    queue={start};visited=set();pages=[];documents=[];candidates=[];seen=set();warnings=[];failed=0;disallowed=0;suggested_name=''
    delay=max(.2,float(rules.crawl_delay('HotelChatImporter') or 0))
    last_request=time.monotonic()
    def request(url, site):
        nonlocal last_request
        wait=max(0,delay-(time.monotonic()-last_request))
        if wait>=deadline-time.monotonic() or wait>30:
            raise TimeoutError('Website verlangt längere Abstände zwischen Anfragen.')
        if wait:time.sleep(wait)
        last_request=time.monotonic()
        return fetcher(url,site)
    original_language=re.match(r'^/(de|it|en|fr|es)(?:/|$)',urllib.parse.urlsplit(start).path)
    original_language=original_language.group(1) if original_language else None
    def page_priority(url):
        language=re.match(r'^/(de|it|en|fr|es)(?:/|$)',urllib.parse.urlsplit(url).path)
        return priority(url)-(10 if language and language.group(1)!=original_language else 0)
    def allowed_link(link,base):
        try:
            target=checked_url(urllib.parse.urljoin(base,html.unescape(link)))
            if not same_site(start,target) or SKIP_PATH.search(urllib.parse.urlsplit(target).path):return None
            if len(urllib.parse.urlsplit(target).path)>350:return None
            return target
        except (ValueError,UnicodeError):return None
    sitemaps=rules.site_maps() or [urllib.parse.urljoin(start,'/sitemap.xml')]
    sitemap_queue=list(sitemaps[:1]);sitemap_count=0
    while sitemap_queue and sitemap_count<2 and time.monotonic()<deadline:
        target=allowed_link(sitemap_queue.pop(0),start)
        if not target or not rules.can_fetch('HotelChatImporter',target):continue
        sitemap_count+=1
        try:
            page=request(target,start)
            if page['status']!=200:continue
            tree=ET.fromstring(page['text']);locations=[el.text.strip() for el in tree.iter() if el.tag.rsplit('}',1)[-1]=='loc' and el.text][:300]
            if tree.tag.rsplit('}',1)[-1]=='sitemapindex':
                sitemap_queue.extend(sorted(locations,key=lambda x:bool(re.search('page|main|de',x)),reverse=True)[:1])
            else:
                for loc in locations:
                    target=allowed_link(loc,start)
                    if target:queue.add(target)
        except Exception:pass
    while queue and len(pages)<max_pages and len(visited)<max_pages+10 and time.monotonic()<deadline:
        url=start if start in queue else sorted(queue,key=lambda x:(-page_priority(x),len(x),x))[0];queue.remove(url)
        if url in visited:continue
        visited.add(url)
        if not rules.can_fetch('HotelChatImporter',url):disallowed+=1;continue
        try:
            page=request(url,start)
            if page['status']!=200 or not any(t in page['type'] for t in ('text/html','application/xhtml+xml')):
                failed+=1;continue
            if not rules.can_fetch('HotelChatImporter',page['url']):disallowed+=1;continue
            if page['url']!=url and page['url'] in visited:continue
            visited.add(page['url'])
            parser,found=candidates_for(page)
            if not pages:
                suggested_name=parser.site_name or parser.title.split('|')[-1].strip()
                suggested_name=suggested_name[:120]
            pages.append({'url':page['url'],'title':parser.title,'characters':sum(len(t) for _,t in parser.text)})
            paragraphs=[(heading+': ' if heading else '')+text for heading,text in parser.text if not re.search(r'cookie|newsletter|marketing|datenschutzerklärung|personenbezogene',text,re.I)]
            paragraphs.extend(text for _,text in structured_blocks(parser))
            documents.append({'url':page['url'],'title':parser.title,'text':'\n\n'.join(dict.fromkeys(paragraphs))[:40000]})
            for row in found:
                fingerprint=(row['category'],row['text'].casefold())
                if fingerprint not in seen and sum(c['category']==row['category'] for c in candidates)<15:
                    seen.add(fingerprint);row['id']='source-'+str(len(candidates)+1);candidates.append(row)
            for link in parser.links:
                target=allowed_link(link,page['url'])
                if target and target not in visited and len(queue)<600:queue.add(target)
        except Exception:
            failed+=1
    if not pages:raise ValueError('Es konnten keine öffentlichen Textseiten gelesen werden. Möglicherweise blockiert die Website den Zugriff oder benötigt JavaScript.')
    if failed:warnings.append(f'{failed} Seiten konnten nicht gelesen werden.')
    if disallowed:warnings.append(f'{disallowed} Seiten wurden wegen der Website-Regeln ausgelassen.')
    if queue:warnings.append('Die Suche wurde nach dem Seiten- oder Zeitlimit beendet. Weitere Inhalte können fehlen.')
    warnings.append('Es werden öffentliche HTML-Texte gelesen. PDFs, Bilder, Buchungssysteme und erst per JavaScript geladene Inhalte sind nicht enthalten. Angaben bitte vor der Übernahme prüfen.')
    return {'hotelId':hotel_id,'requestedUrl':start,'suggestedName':suggested_name,'scannedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pages':pages,'documents':documents,'candidates':candidates,'warnings':warnings}
