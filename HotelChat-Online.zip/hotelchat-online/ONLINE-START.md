# HotelChat – vorbereitete Serverversion

Diese Version ist separat von der bisherigen Vorschau. Sie wurde lokal geprüft, aber noch nicht auf Render veröffentlicht. Die bestehende App auf Port 8794 wurde nicht neu gestartet. Die neue lokale Verwaltung läuft auf Port 8795.

## Was fertig implementiert ist

- Betreiberkonto mit allen Hotels; Hotelkonten mit serverseitig erzwungenem Zugriff auf genau ein Hotel.
- Scrypt-Passwortspeicherung, zwölfstündige widerrufbare Sitzungen, geschützte Cookies im Onlinebetrieb, Herkunfts- und CSRF-Prüfung, Anfragenbegrenzung. Einladungslinks gelten einmalig für 48 Stunden; Rücksetzlinks einmalig für eine Stunde. Gesperrte Hotelzugänge verlieren ihre Sitzungen sofort.
- Hotelprofile und eingelesene Quellen in einer dauerhaften SQLite-Datenbank. Die App übernimmt keine Hotelangaben aus Gastanfragen. Website-Import, individuelle Gestaltung, Logo und Buchungslink bleiben pro Hotel getrennt.
- Verschlüsselter API-Schlüssel in der Datenbank. Der unabhängige Hauptschlüssel kommt aus der Serverumgebung und gehört nicht ins Repository. Der Browser erhält weder diesen Hauptschlüssel noch den gespeicherten API-Schlüssel.
- Monatliches und tägliches Gesamtlimit, tägliches Limit pro Hotel. Vor einem neuen KI-Aufruf wird ein konservativer Betrag atomar reserviert. Bekannte Tokenzahlen ersetzen die Reservierung durch die Schätzung. Bei einem Timeout oder fehlenden Abrechnungsdaten bleibt die Reservierung bestehen. Zeitzone der Limits: UTC. Standard: 2 USD/Tag gesamt, 20 USD/Monat gesamt, 1 USD/Hotel/Tag. Alle Werte können auf 0 gesetzt werden. Schätzung ohne Steuern; sie ersetzt kein Ausgabenlimit beim KI-Anbieter.
- 24-Stunden-Speicher für streng erkannte öffentliche, eigenständige Hotel-FAQs; keine persönlichen Verläufe im gemeinsamen Speicher. Bereits gespeicherte Antworten brauchen keine neue Budgetreservierung. Neue bzw. kontextabhängige Fragen gehen weiter an die KI.
- Eigener Demo-Link und Einbaucode pro Hotel. Das eingebettete Fenster ist von der Hotelwebsite getrennt. Zugelassene Einbau-Adressen werden explizit eingetragen. Der Chat beginnt erst nach dem Klick auf „KI-Chat starten“. Keine Anmelde-Cookies für Gäste nötig. Das interne Testfenster benötigt einen angemeldeten Betreiber-/Hotelzugang.
- Keine dauerhaften Gastprotokolle. Gäste sehen keine Modellnamen, Kostenbeträge, Tokenzahlen oder Zugangsschlüssel. Kurzfristige Anfragenzähler enthalten nur einen geheimnisgebundenen IP-Prüfwert. Hosting- und KI-Anbieter haben eigene Datenverarbeitung.
- Freigabeprüfung für Betreiberangaben, Hotel-Datenschutzlink, geprüfte Antworten, Dienstleisterprüfung, eingelesene Quellen, KI-Verbindung und erlaubte Websites. Fehlende Betreiberangaben sperren Demo und Gastwidget. Eine interne Vorschau bleibt möglich. Die Häkchen dokumentieren die manuelle Prüfung, sie führen keine Rechtsprüfung durch.
- Tägliche geprüfte SQLite-Sicherungen, sieben Tage Aufbewahrung, auf demselben Datenträger. `backup.py` erzeugt zusätzlich eine manuelle Sicherung. Der Hauptschlüssel wird nicht mitkopiert.

## Jetzt lokal öffnen

Die Datei **„Neue HotelChat-Verwaltung starten.command“** im übergeordneten `outputs`-Ordner startet die neue Version und öffnet bei der ersten Einrichtung den geschützten Einrichtungslink. E-Mail und eigenes Passwort direkt dort eingeben, nicht im Chat. Ab der zweiten Nutzung reicht die normale Anmeldung.

Die lokalen Bibliotheken liegen für diese Testumgebung in `work/online-deps`; das ist kein Bestandteil des Veröffentlichungsarchivs. Auf einem anderen Rechner zuerst Python 3.12 und die Bibliotheken aus `requirements.txt` in einer eigenen virtuellen Umgebung installieren. `local.py` ist ausschließlich für die lokale Einrichtung, nicht der öffentliche Webserver.

Das eingelesene Wissen von Hotel Erzherzog Johann wurde als Entwurf übernommen. Eigene Ergänzungen und Gestaltung aus der alten Browserverwaltung werden nicht stillschweigend überschrieben oder als geprüft übernommen. Bitte diese Angaben im neuen Hotelprofil kontrollieren. Die alte Version bleibt dafür erhalten. Die KI-Verbindung muss in dieser neuen Verwaltung einmal eingerichtet werden; der nur im Speicher der alten App liegende Schlüssel wurde nicht ausgelesen.

## Render vorbereiten und veröffentlichen

1. Dieses Verzeichnis als Repository-Inhalt bereitstellen. **Keine** `data`-Dateien, lokale Schlüssel oder Sicherungen hochladen. Das beigefügte ZIP enthält nur Programmdateien und Anleitungen.
2. Im eigenen Render-Konto einen neuen Service oder Blueprint mit `render.yaml` anlegen. Einen vorhandenen Service erst nach gesicherter Datenübernahme ersetzen. Die Vorlage verwendet einen kostenpflichtigen Webservice plus dauerhaften Datenträger. Vor dem kostenpflichtigen Erstellen müssen Plan und Preis im Konto bestätigt werden; diese Aktion wurde hier nicht ausgeführt.
3. Gewählte öffentliche Adresse als `PUBLIC_URL` setzen, z. B. `https://hotelchat-...onrender.com`, ohne abschließende Unterseite. Der Service startet absichtlich nicht, wenn die Adresse oder der Hauptschlüssel fehlen. Für eine eigene Domain muss `PUBLIC_URL` entsprechend angepasst werden.
4. `HOTELCHAT_MASTER_KEY` und `HOTELCHAT_BOOTSTRAP_TOKEN` von Render erzeugen lassen. Alternativ jeweils mit `python -c "import secrets; print(secrets.token_urlsafe(48))"` erzeugen und direkt als geschützte Umgebungsvariable eintragen. Den Hauptschlüssel unabhängig und sicher sichern. Nicht zusammen mit der Datenbanksicherung ablegen; ohne ihn kann der gespeicherte API-Schlüssel nach einer Wiederherstellung nicht entschlüsselt werden.
5. Erster Start mit `gunicorn --workers 1 --threads 8 --timeout 180 --bind 0.0.0.0:$PORT wsgi:app`. Diese SQLite-Version ist für **einen Service mit einem persistenten Datenträger** ausgelegt. Sie ist nicht für mehrere unabhängig skalierende Instanzen vorbereitet. Die Vorlage aktiviert die Auswertung genau eines vorgeschalteten Render-Proxys; außerhalb dieser Umgebung muss die Proxykonfiguration geprüft werden.
6. Im eigenen Browser `PUBLIC_URL/setup#HOTELCHAT_BOOTSTRAP_TOKEN` öffnen; die tatsächliche Variable direkt aus Render übernehmen. Das Fragment erscheint nicht in HTTP-Zugriffsprotokollen. Eigenes Betreiberkonto anlegen. Ein zweites Betreiberkonto kann über diesen Weg nicht erzeugt werden. Danach den Bootstrap-Wert aus der Umgebung entfernen.
7. In den Einstellungen KI verbinden, Limits setzen und später Betreiberangaben ergänzen. Hotel anlegen, Website einlesen, Angaben prüfen. Die gewählte Render-Region ist Frankfurt; daraus folgt keine Zusage, dass Anthropic die KI-Anfragen ausschließlich in der EU verarbeitet.
8. Hotel-Datenschutzhinweise und Dienstleisterverträge klären. Zuständigkeiten, Rechtsgrundlage, Speicherfristen und internationale Übermittlung müssen zum tatsächlichen Betreiber und Konto passen. Die mitgelieferte technische Beschreibung ist kein fertiger, rechtlich geprüfter Datenschutztext. Der Nutzer hat die Betreiberangaben ausdrücklich auf später verschoben; diese wurden nicht erfunden.
9. Je Hotel die genaue HTTPS-Herkunft eintragen, etwa `https://www.hotel.at` und bei Bedarf zusätzlich `https://hotel.at`. Alle Prüfpunkte vervollständigen und auf „Für Gäste freigegeben“ stellen. Demo-Link an das Hotel schicken; Einbaucode von dessen Webagentur in die Website einsetzen lassen. Bei einer strengen Sicherheitsrichtlinie der Hotelwebsite müssen die HotelChat-Adresse für Skripte und Frames erlaubt werden.
10. Live unter HTTPS prüfen: Anmeldung/Abmeldung, Hotelzugang ohne fremde Daten, Demo, tatsächliche Einbettung, Zustimmung vor erster KI-Anfrage, Darstellung auf Mobilgeräten, wichtige Antworten und Quellen, Pause und Kostenlimit. Ein öffentlicher Live-Test wurde noch nicht durchgeführt.

## Sicherung und Wiederherstellung

Die automatische lokale Sicherung schützt vor Bedien- und Datenbankfehlern, nicht vor Verlust des gesamten Datenträgers. Für den echten Betrieb eine zweite verschlüsselte Sicherung außerhalb des Services einrichten und deren Zugriff/Fristen festlegen. Das ist noch nicht mit einem externen Speicher verbunden.

Vor Änderungen `python backup.py` ausführen. Zur Wiederherstellung den Service stoppen, die bisherige Datenbank einschließlich `-wal`/`-shm` sicher beiseitelegen und eine geprüfte Sicherung als `HOTELCHAT_DATA_DIR/hotelchat.sqlite3` einsetzen. Nur bei gestopptem Service ersetzen. Den dazugehörigen Hauptschlüssel wiederherstellen, anschließend Anmeldung, Profile und KI-Verbindung prüfen. Dieser Ablauf wurde an einer getrennten Testdatenbank geprüft. Kein direktes Zurückspielen alter Datenträgerschnappschüsse in eine laufende SQLite-Datenbank.

Vergessenes Betreiberpasswort: `PUBLIC_URL` und `HOTELCHAT_DATA_DIR` in der vertrauenswürdigen Serverumgebung setzen und `python recover.py` ausführen. Den erzeugten, einstündigen Link ausschließlich dem Betreiber geben. Er setzt nur das Passwort zurück und widerruft vorhandene Sitzungen. Kein Passwort per Chat mitteilen. Für Hotelkonten kann der Betreiber in der Oberfläche einen Rücksetzlink erstellen oder den Zugang sperren.

## Prüfung und Grenzen

Automatisierte Integrationsprüfungen stehen in `TESTERGEBNIS.md`. Sie prüfen Zugriffsrechte, Quellen-/Cachetrennung, persönliche Nachrichten, Manipulationsversuche, Limits, Sitzungen, Einladungen und Sicherungen. KI-Antworten wurden in den neuen Sicherheitsprüfungen mit einem kontrollierten Anbieterersatz geprüft, um keine zusätzlichen Gebühren zu erzeugen. Die eigentliche KI- und Quellenlogik stammt aus der bereits getesteten Vorschau.

Eine unabhängige Sicherheitsprüfung, Lastprüfung im öffentlichen Betrieb, rechtliche Freigabe und reale Hotel-Einbettung sind damit nicht ersetzt. Es gibt keine Zusage „100 % richtige Antworten“. Livepreise, freie Zimmer und Buchungen benötigen eine echte Anbindung an das Buchungssystem; ein Website-Import kann sie nicht zuverlässig liefern.

## Offizielle Grundlagen

- [Flask: Sicherheitskonfiguration](https://flask.palletsprojects.com/en/stable/web-security/)
- [Render: Flask veröffentlichen](https://render.com/docs/deploy-flask)
- [Render: dauerhafte Datenträger](https://render.com/docs/disks)
- [Render: Blueprint-Konfiguration](https://render.com/docs/blueprint-spec)
- [Anthropic: API und Datenaufbewahrung](https://platform.claude.com/docs/en/build-with-claude/api-and-data-retention)

Die Auswahl der tatsächlichen Anbieter- und Datenschutzbedingungen muss vor der Freigabe anhand des verwendeten Kontos erfolgen.

## Vollständige verschlüsselte Sicherung außerhalb des Servers

Unter Einstellungen kann ausschließlich der Betreiber eine vollständige Sicherung aller Hotelprofile, Quellen, Konten und der verschlüsselten KI-Verbindung herunterladen. Dafür direkt in der Oberfläche ein eigenes Sicherungspasswort mit mindestens 16 Zeichen wählen. Die Datei enthält Datenbank und zugehörigen Hauptschlüssel ausschließlich innerhalb einer mit Scrypt und Fernet verschlüsselten Hülle. Das Sicherungspasswort wird nicht gespeichert. Die Datei anschließend selbst auf einem externen Laufwerk oder im eigenen Cloudspeicher ablegen und das Passwort getrennt aufbewahren. Ein automatischer Upload zu einem Cloudanbieter ist noch nicht eingerichtet.

Wiederherstellung nur in einen neuen, leeren Ordner:

```sh
python secure_backup.py HotelChat-Sicherung.hotelchat wiederhergestellt
```

Das Passwort wird verdeckt abgefragt. Nach erfolgreicher Prüfung liegen dort die Datenbank und eine nur für den Eigentümer lesbare Hauptschlüsseldatei. Vor der Wiederherstellung des Dienstes alle laufenden Instanzen stoppen. Vorhandene Sitzungen und offene Einladungen werden beim Wiederherstellen gelöscht, damit eine alte Sicherung keine widerrufenen Zugänge wieder aktiviert. Den Hauptschlüssel direkt in der geschützten Serverumgebung setzen, nicht im Chat mitteilen.
