import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('knowledge',ROOT/'knowledge.py')
knowledge=importlib.util.module_from_spec(spec);spec.loader.exec_module(knowledge)

class KnowledgeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.store=knowledge.SourceStore(Path(self.temp.name)/'sources.sqlite3')
        self.hotel_a={'hotelId':'hotel-a','requestedUrl':'https://a.example/','scannedAt':'2026-11-23T00:00:00Z','documents':[
            {'url':'https://a.example/agbs','title':'Hotel A · Angaben','text':'Ihr Zimmer ist ab 13 Uhr bezugsfertig.\n\nWir bitten Sie das Zimmer bis 10 Uhr freizugeben.\n\nHunde dürfen nach schriftlicher Bestätigung mitgebracht werden. Es wird ein Tagessatz von 19 Euro ohne Futter berechnet.\n\nUnser WLAN ist für Gäste kostenlos.\n\nUnser beheiztes Hallenbad ist täglich geöffnet.'},
            {'url':'https://a.example/gourmet','title':'Hotel A · Gourmet','text':'Unser Frühstücksbuffet wird auf der Terrasse serviert. Es gibt vegetarische Abendmenüs.'}]}
        self.store.save(self.hotel_a)
        self.store.save({'hotelId':'hotel-b','requestedUrl':'https://b.example/','scannedAt':'now','documents':[{'url':'https://b.example','title':'Hotel B','text':'Ihr Zimmer ist ab 17 Uhr bezugsfertig. Hunde sind nicht erlaubt.'}]})

    def ask(self,q,hotel='hotel-a',website='https://a.example/',**options):
        return knowledge.answer(self.store,hotel,website,'Hotel A',q,{},options.pop('history',[]),**options)

    def test_paraphrases_retrieve_original_answers(self):
        cases=[('Ab wann kann ich mein Zimmer beziehen?','13 Uhr'),('Sind Haustiere erlaubt und was kosten sie?','19 Euro'),('Haben Sie Internet?','WLAN'),('Kann ich im Pool schwimmen?','Hallenbad')]
        for question,expected in cases:
            with self.subTest(question=question):
                answer=self.ask(question)
                self.assertIn(expected,answer['text'])
                self.assertTrue(answer['sources'])
                self.assertTrue(all(source['url'].startswith('https://a.example') for source in answer['sources']))

    def test_full_page_knowledge_used_without_category_selection(self):
        self.assertIn('vegetarische',self.ask('Gibt es vegetarisches Essen?')['text'])

    def test_other_hotels_never_enter_retrieval_or_model_context(self):
        result=self.ask('Ab wann kann ich mein Zimmer beziehen?',hotel='hotel-b',website='https://b.example/')
        self.assertIn('17 Uhr',result['text']);self.assertNotIn('13 Uhr',result['text'])
        captured=[]
        def provider(payload,key):captured.append(payload);raise TimeoutError()
        self.ask('Check-in',key='test-key',provider=provider)
        self.assertNotIn('17 Uhr',str(captured[0]));self.assertNotIn('b.example',str(captured[0]))

    def test_unknown_details_are_not_invented(self):
        result=self.ask('Welche Ladesäulen für Elektrofahrzeuge bieten Sie an?')
        self.assertEqual(result['mode'],'setup-required');self.assertEqual(result['sources'],[])
        # Breakfast is described, but no invented breakfast time is added.
        result=self.ask('Wann gibt es Frühstück?')
        self.assertNotRegex(result['text'],r'7[:.]00|10[:.]30')

    def test_changed_website_does_not_reuse_old_import(self):
        self.assertEqual(self.ask('Check-in',website='https://other.example/')['mode'],'missing-import')

    def test_followup_keeps_topic_but_new_unknown_subject_does_not(self):
        history=[{'role':'user','content':'Darf mein Hund mitkommen?'}]
        self.assertIn('19 Euro',self.ask('Was kostet das?',history=history)['text'])
        self.assertEqual(self.ask('Gibt es eine Ladesäule für Elektroautos?',history=history)['mode'],'setup-required')
        self.assertIn('13 Uhr',self.ask('Check-in',history=history)['text'])

    def test_sources_survive_server_restart(self):
        restored=knowledge.SourceStore(Path(self.temp.name)/'sources.sqlite3')
        self.assertEqual(restored.get('hotel-a')['documents'][0]['url'],'https://a.example/agbs')

    def test_invalid_citations_and_uncited_claims_fall_back(self):
        chunks=[{'text':'Check-in ab 13 Uhr.','url':'https://a.example','title':'Hotel A'}]
        valid={'type':'char_location','document_index':0,'start_char_index':0,'end_char_index':len(chunks[0]['text']),'cited_text':chunks[0]['text']}
        good={'content':[{'type':'text','text':'Der Check-in ist ab 13 Uhr möglich.','citations':[valid]}]}
        self.assertEqual(knowledge.validated_reply(good,chunks)['mode'],'ai')
        forged={'content':[{'type':'text','text':'Check-in ab 8 Uhr.','citations':[{**valid,'document_index':1}]}]}
        self.assertIsNone(knowledge.validated_reply(forged,chunks))
        mixed={'content':good['content']+[{'type':'text','text':'Frühstück ist kostenlos.'}]}
        filtered=knowledge.validated_reply(mixed,chunks)
        self.assertEqual(filtered['text'],'Der Check-in ist ab 13 Uhr möglich.')
        self.assertNotIn('Frühstück',filtered['text'])

    def test_provider_failure_is_explicit_instead_of_silent_search_fallback(self):
        def provider(payload,key):raise TimeoutError()
        result=self.ask('Check-in',key='test-key',provider=provider)
        self.assertEqual(result['mode'],'ai-error');self.assertEqual(result['sources'],[])

    def test_ai_receives_all_hotel_information_even_for_zero_keyword_matches(self):
        captured=[]
        def provider(payload,key):
            captured.append(payload)
            first=payload['messages'][0]['content'][0]['source']['data']
            return {'content':[{'type':'text','text':'Das Hotel heißt Hotel A.','citations':[{'type':'char_location','document_index':0,'start_char_index':0,'end_char_index':len(first),'cited_text':first}]}]}
        result=self.ask('wie heißt das hotel',key='test-key',provider=provider)
        self.assertEqual(result['mode'],'ai');self.assertIn('Hotel A',result['text'])
        context=str(captured[0]['messages'][0]['content'])
        self.assertIn('Name des Hotels: Hotel A',context)
        self.assertIn('19 Euro',context);self.assertIn('vegetarische',context)
        self.assertNotIn('17 Uhr',context);self.assertNotIn('b.example',context)

    def test_citation_value_and_uncited_prefix_form_one_grounded_sentence(self):
        chunks=[{'text':'Name des Hotels: Hotel A','url':'https://a.example','title':'Name'}]
        response={'content':[{'type':'text','text':'Das Hotel heißt '},{'type':'text','text':'Hotel A','citations':[{'type':'char_location','document_index':0,'start_char_index':17,'end_char_index':24,'cited_text':'Hotel A'}]},{'type':'text','text':'.'}]}
        # Use exact character positions from the document instead of assumed offsets.
        cite=response['content'][1]['citations'][0];cite['start_char_index']=chunks[0]['text'].index('Hotel A');cite['end_char_index']=cite['start_char_index']+7
        self.assertEqual(knowledge.validated_reply(response,chunks)['text'],'Das Hotel heißt Hotel A.')

    def test_hotel_location_joins_split_footer_address_and_ignores_email(self):
        self.hotel_a['documents'].append({'url':'https://a.example/','title':'Hotel in Schenna','text':'Ihr Hotel in Schenna\n\ninfo@hotel.example\n\nIhr Urlaubs journal: HOTEL A\n\nIhr Urlaubs journal: Familie Pichler, Schlossweg 19\n\nIhr Urlaubs journal: I-39017 Schenna, Südtirol, Italien\n\nAlles neu im Eingangsbereich und der Bar\n\nImpressum | Datenschutz'})
        self.store.save(self.hotel_a)
        for question in ['Wo ist das Hotel?','wo ist das hotel','Wo befindet sich das Hotel?','Wie lautet die Adresse?','In welchem Ort liegt das Hotel?','Wo seid ihr?','Where is the hotel?']:
            with self.subTest(question=question):
                result=self.ask(question)
                self.assertEqual(result['mode'],'address')
                self.assertIn('Schlossweg 19',result['text'])
                self.assertIn('39017 Schenna, Südtirol, Italien',result['text'])
                self.assertNotIn('@',result['text'])
                self.assertNotIn('Impressum',result['text'])
                self.assertNotIn('Eingangsbereich',result['text'])
                self.assertEqual(result['text'],'Die Adresse des Hotels lautet:\n\nSchlossweg 19\n39017 Schenna, Südtirol, Italien')
                self.assertEqual(len(result['sources']),1)
                self.assertEqual(result['sources'][0]['url'],'https://a.example/')

    def test_missing_hotel_address_does_not_return_email_or_other_hotel(self):
        self.hotel_a['documents'].append({'url':'https://a.example','title':'Hotel A','text':'HOTEL A\n\nSchlossweg 19\n\n39017 Schenna, Italien'})
        self.store.save(self.hotel_a)
        result=self.ask('Wo ist das Hotel?',hotel='hotel-b',website='https://b.example/')
        self.assertEqual(result['mode'],'unknown');self.assertNotIn('Schlossweg',result['text'])

    def test_missing_street_number_is_not_guessed(self):
        self.assertEqual(self.ask('Wo ist das Hotel?')['mode'],'unknown')

    def test_spatial_questions_about_other_amenities_are_not_hotel_address(self):
        for question in ['Wo ist der Pool im Hotel?','Wo kann ich beim Hotel parken?','Wo ist das Restaurant?']:
            self.assertFalse(knowledge.asks_location(question))

    def test_same_page_is_listed_once_even_with_different_titles(self):
        chunks=[{'text':'Ein passender Text.','url':'https://a.example/','title':'Hotel A'},{'text':'Ein weiterer Text.','url':'https://a.example/','title':'Hotel A · Startseite'}]
        self.assertEqual(len(knowledge.excerpts_answer(chunks)['sources']),1)

    def test_cache_contains_stable_hotel_prefix_and_excludes_guest_conversation(self):
        chunks=knowledge.complete_context(self.hotel_a,{},'Hotel A')
        first=knowledge.make_payload('Hotel A','Wie heißt das Hotel?',chunks,[],'test-model',hotel_id='hotel-a')
        second=knowledge.make_payload('Hotel A','Wo ist das Hotel?',chunks,[{'role':'user','content':'Vorherige Gastfrage'}],'test-model',hotel_id='hotel-a')
        prefix_a=first['messages'][0]['content'][:-1];prefix_b=second['messages'][0]['content'][:-1]
        self.assertEqual(prefix_a,prefix_b)
        self.assertEqual(prefix_a[-1]['cache_control'],{'type':'ephemeral','ttl':'1h'})
        self.assertIn('1h-v1',prefix_a[0]['context'])
        self.assertNotIn('cache_control',first['messages'][0]['content'][-1])
        self.assertNotIn('Vorherige Gastfrage',str(prefix_b))
        other=knowledge.make_payload('Hotel A','Wo ist das Hotel?',chunks,[],'test-model',hotel_id='hotel-b')
        self.assertNotEqual(other['messages'][0]['content'][0],prefix_a[0])

    def test_cache_statistics_are_returned_without_provider_secrets(self):
        self.assertEqual(knowledge.usage_stats({'usage':{'input_tokens':100,'output_tokens':50,'cache_creation_input_tokens':2000,'cache_read_input_tokens':4000,'unexpected':'ignored'}}),{'input_tokens':100,'output_tokens':50,'cache_creation_input_tokens':2000,'cache_read_input_tokens':4000})

    def test_low_cost_model_is_persisted_and_overrides_legacy_running_default(self):
        settings=Path(self.temp.name)/'ai-settings.json';settings.write_text('{"model":"claude-haiku-5-5"}')
        with patch.object(knowledge,'MODEL_SETTINGS',settings):
            self.assertEqual(knowledge.effective_model('claude-sonnet-5-5'),'claude-haiku-5-5')

    def test_actual_usage_costs_distinguish_cold_and_cached_haiku_requests(self):
        cold={'input_tokens':90,'cache_creation_input_tokens':22025,'cache_read_input_tokens':0,'output_tokens':85}
        warm={'input_tokens':90,'cache_creation_input_tokens':0,'cache_read_input_tokens':22025,'output_tokens':85}
        self.assertAlmostEqual(knowledge.estimated_cost_usd(cold,'claude-haiku-5-5'),.002804625)
        self.assertAlmostEqual(knowledge.estimated_cost_usd(warm,'claude-haiku-5-5'),.00027175)
        self.assertLess(knowledge.estimated_cost_usd(cold,'claude-haiku-5-5'),knowledge.estimated_cost_usd(cold,'claude-sonnet-5-5')/19)
        self.assertIsNone(knowledge.estimated_cost_usd(cold,'unknown-model'))

    def test_one_hour_cache_creation_is_metered_at_correct_higher_rate(self):
        response={'usage':{'input_tokens':90,'cache_creation_input_tokens':22025,'cache_read_input_tokens':0,'output_tokens':85,'cache_creation':{'ephemeral_1h_input_tokens':22025,'ephemeral_5m_input_tokens':0}}}
        usage=knowledge.usage_stats(response)
        self.assertEqual(usage['cache_creation']['ephemeral_1h_input_tokens'],22025)
        self.assertAlmostEqual(knowledge.estimated_cost_usd(usage,'claude-haiku-5-5'),.0044565)

if __name__=='__main__':unittest.main()
