import copy
import importlib.util
from pathlib import Path
import tempfile
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('knowledge_cache_test',ROOT/'knowledge.py')
k=importlib.util.module_from_spec(spec);spec.loader.exec_module(k)

class AnswerCacheTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.store=k.SourceStore(Path(self.temp.name)/'hotel.sqlite3')
        self.snapshot={'hotelId':'hotel-a','requestedUrl':'https://a.example/','scannedAt':'2026-11-23T00:00:00Z','documents':[{'url':'https://a.example/','title':'Hotel A','text':'Das Hotel A liegt am Stadtpark. Frühstück ab 7 Uhr.'}]}
        self.store.save(self.snapshot)
        self.store.save({'hotelId':'hotel-b','requestedUrl':'https://b.example/','scannedAt':'now','documents':[{'url':'https://b.example/','title':'Hotel B','text':'Hotel B liegt am See. Frühstück ab 9 Uhr.'}]})
        self.calls=0;self.payloads=[]

    def provider(self,payload,key):
        self.calls+=1;self.payloads.append(payload)
        text=payload['messages'][0]['content'][0]['source']['data']
        name=text.split(': ',1)[1]
        return {'content':[{'type':'text','text':'Das Hotel heißt '+name+'.','citations':[{'type':'char_location','document_index':0,'start_char_index':0,'end_char_index':len(text),'cited_text':text}]}],'usage':{'input_tokens':100,'output_tokens':30}}

    def ask(self,question='Wie heißt das Hotel?',history=None,facts=None,hotel='hotel-a',name='Hotel A',website='https://a.example/',provider=None,key='FAKE-TEST-KEY'):
        return k.answer(self.store,hotel,website,name,question,facts or {},history or [],key=key,provider=provider or self.provider)

    def rows(self):
        with self.store.connect() as db:return db.execute('SELECT * FROM public_answer_cache').fetchall()

    def test_fresh_second_guest_gets_same_public_answer_without_provider_call(self):
        first=self.ask();second=self.ask('  WIE heißt das Hotel???  ')
        self.assertEqual(first['mode'],'ai');self.assertTrue(first['answer_cache_stored'])
        self.assertEqual(second['mode'],'answer-cache');self.assertTrue(second['answer_cache_hit'])
        self.assertEqual(second['text'],first['text']);self.assertEqual(self.calls,1)
        self.assertEqual(second['estimated_cost_usd'],0)
        self.assertTrue(all(value==0 for value in second['usage'].values()))

    def test_transcripts_and_personal_questions_never_read_or_write_shared_answers(self):
        self.ask()
        history=[{'role':'user','content':'Mein Name ist EVA-PRIVATE, ich wohne in Zimmer 512.'}]
        result=self.ask(history=history)
        self.assertEqual(result['mode'],'ai');self.assertEqual(self.calls,2)
        for question in ['Wie heißt das Hotel? Mein Name ist ALICE-PRIVATE.','Ich bin BOB-PRIVATE aus Zimmer 12, wann gibt es Frühstück?','Was kostet meine Buchung 12345?','Wo ist das Hotel? Meine E-Mail ist guest@example.net','Sind Hunde erlaubt? Ich habe eine Allergie.']:
            result=self.ask(question)
            self.assertNotIn('answer_cache_stored',result)
        rows=str(self.rows())
        for secret in ['EVA-PRIVATE','ALICE-PRIVATE','BOB-PRIVATE','guest@example.net','FAKE-TEST-KEY','Wie heißt das Hotel?']:
            self.assertNotIn(secret,rows)
        self.assertEqual(len(self.rows()),1)

    def test_other_hotel_never_gets_first_hotels_answer(self):
        self.ask()
        other=self.ask(hotel='hotel-b',name='Hotel B',website='https://b.example/')
        self.assertEqual(other['mode'],'ai');self.assertIn('Hotel B',other['text']);self.assertNotIn('Hotel A',other['text'])
        again=self.ask(hotel='hotel-b',name='Hotel B',website='https://b.example/')
        self.assertEqual(again['mode'],'answer-cache');self.assertEqual(self.calls,2)

    def test_cache_expires_after_24_hours_without_sliding_extension(self):
        with patch.object(k.time,'time',return_value=1000):self.ask()
        with patch.object(k.time,'time',return_value=1000+86399):hit=self.ask()
        self.assertEqual(hit['answer_cache_expires_at'],1000+86400)
        self.assertEqual(self.calls,1)
        with patch.object(k.time,'time',return_value=1000+86400):expired=self.ask()
        self.assertEqual(expired['mode'],'ai');self.assertEqual(self.calls,2)

    def test_reimport_invalidates_even_if_public_text_is_unchanged(self):
        self.ask();updated=copy.deepcopy(self.snapshot);updated['scannedAt']='2026-11-24T00:00:00Z';self.store.save(updated)
        self.assertEqual(self.ask()['mode'],'ai');self.assertEqual(self.calls,2)

    def test_changed_knowledge_name_and_manual_facts_invalidate(self):
        self.ask();updated=copy.deepcopy(self.snapshot);updated['documents'][0]['text']='Neue Frühstückszeit: ab 8 Uhr.';self.store.save(updated)
        self.assertEqual(self.ask()['mode'],'ai')
        self.assertIn('ab 8 Uhr',str(self.payloads[-1]))
        self.assertEqual(self.ask(name='Hotel A Neu')['mode'],'ai')
        self.assertEqual(self.ask(facts={'breakfast':'Jetzt ab 9 Uhr'})['mode'],'ai')
        self.assertEqual(self.calls,4)

    def test_language_and_question_meaning_are_not_fuzzily_merged(self):
        self.ask();self.assertEqual(self.ask('What is the hotel name?')['mode'],'ai')
        self.assertEqual(self.calls,2)
        self.assertIsNone(k.public_question_key('Sind Hunde nicht erlaubt?',[]))
        self.assertIsNone(k.public_question_key('Gibt es morgen freie Zimmer?',[]))
        self.assertIsNone(k.public_question_key('Was kostet ein Zimmer am 24.12.?',[]))

    def test_failure_and_unverified_answers_are_not_saved(self):
        def failed(payload,key):raise TimeoutError()
        self.assertEqual(self.ask(provider=failed)['mode'],'ai-error')
        self.assertFalse(self.rows())
        unverified=lambda payload,key:{'content':[{'type':'text','text':'Eine unbestätigte Angabe.'}]}
        self.assertEqual(self.ask(provider=unverified)['mode'],'ai-unverified')
        self.assertFalse(self.rows())

    def test_cache_survives_restart_and_does_not_require_reusing_a_guest_session(self):
        self.ask();self.store=k.SourceStore(Path(self.temp.name)/'hotel.sqlite3')
        self.assertEqual(self.ask(key='')['mode'],'answer-cache');self.assertEqual(self.calls,1)

    def test_simultaneous_guests_produce_only_one_paid_request(self):
        gate=threading.Barrier(3)
        def slow_provider(payload,key):time.sleep(.04);return self.provider(payload,key)
        def work(_):gate.wait(timeout=2);return self.ask(provider=slow_provider)
        with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(work,range(3)))
        self.assertEqual(self.calls,1)
        self.assertEqual(sum(result['mode']=='answer-cache' for result in results),2)
        self.assertFalse(k._ANSWER_LOCKS)

if __name__=='__main__':unittest.main()
