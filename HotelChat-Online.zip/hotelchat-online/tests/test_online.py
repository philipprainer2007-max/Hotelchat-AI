import json
import sys
import tempfile
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app import create_app, profile
from store import Store
import knowledge

BASE='https://chat.example'
PW='test-only-long-password-2026'


class OnlineTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.calls=[]
        self.app=create_app({'TESTING':True,'DATA_DIR':self.temp.name,'PUBLIC_URL':BASE,
            'MASTER_KEY':'test-only-master-key-not-for-production-123456789',
            'BOOTSTRAP_TOKEN':'test-only-bootstrap','PROVIDER':self.provider})
        self.client=self.app.test_client();self.db=self.app.extensions['store'];self.sources=self.app.extensions['sources']
        self.owner=self.db.bootstrap('owner@example.test',PW)
        self.sign_in(self.client,self.owner)
        self.a=self.db.save_hotel(profile({'name':'Hotel Alpha','website':'https://alpha.example/','facts':{'other':'ALPHA-ONLY-PRIVATE-HOTEL-FACT'}}))
        self.b=self.db.save_hotel(profile({'name':'Hotel Beta','website':'https://beta.example/','facts':{'other':'BETA-ONLY-PRIVATE-HOTEL-FACT'}}))
        for h in (self.a,self.b):
            self.sources.save({'hotelId':h['id'],'requestedUrl':h['website'],'scannedAt':'now','documents':[{'title':h['name'],'url':h['website'],'text':'Check-in ab 13 Uhr. Frühstück ab 7 Uhr.'}]})
        self.db.set_setting('anthropicKey',None)
        self.keypatch=patch.dict('os.environ',{'ANTHROPIC_API_KEY':'sk-ant-TEST-NOT-REAL'});self.keypatch.start();self.addCleanup(self.keypatch.stop)

    def sign_in(self,client,uid):
        client.set_cookie('hotelchat_session',self.db.new_session(uid),domain='chat.example')

    def csrf(self,client):
        return client.get('/api/state',base_url=BASE).json.get('token','')

    def post(self,path,body,client=None,method='POST',origin=BASE,csrf=True):
        client=client or self.client
        headers={'Origin':origin}
        if csrf: headers['X-HotelChat-Token']=self.csrf(client)
        return client.open(path,method=method,json=body,headers=headers,base_url=BASE)

    def provider(self,payload,key):
        self.calls.append(payload)
        text=payload['messages'][0]['content'][0]['source']['data'];name=text.split(': ',1)[1]
        return {'content':[{'type':'text','text':'Das Hotel heißt '+name+'.','citations':[{'type':'char_location','document_index':0,'start_char_index':0,'end_char_index':len(text),'cited_text':text}]}],'usage':{'input_tokens':100,'output_tokens':30}}

    def hotel_user(self,h):
        token=self.db.invite('hotel@example.test',h['id']);uid=self.db.accept(token,PW)
        client=self.app.test_client();self.sign_in(client,uid)
        return client,uid

    def publish(self,h):
        self.db.set_setting('operator',{'name':'Test Operator','address':'Example Street 1','email':'operator@example.test'})
        h=self.db.save_hotel(profile({**h,'status':'ready','allowedOrigins':['https://hotel.example'],'privacyUrl':'https://hotel.example/privacy','privacyReviewed':True,'answersReviewed':True,'contractsReviewed':True},h),h['revision'])
        return h

    def start(self,h,client=None):
        return self.post('/api/public/start',{'hotelId':h['id'],'parent':'https://hotel.example'},client=client,csrf=False)

    def ask(self,h,q='Wie heißt das Hotel?',**extra):
        return self.post('/api/chat',{'hotelId':h['id'],'question':q,'history':[],**extra})

    def test_anonymous_cannot_list_edit_import_or_chat(self):
        stranger=self.app.test_client()
        self.assertFalse(stranger.get('/api/state',base_url=BASE).json['authenticated'])
        for route,body in [('/api/chat',{'hotelId':self.a['id']}),('/api/import',{'hotelId':self.a['id']}),('/api/hotels',{'name':'attacker'}),('/api/settings',{})]:
            self.assertEqual(self.post(route,body,client=stranger,csrf=False).status_code,401)

    def test_hotel_login_only_sees_own_tenant(self):
        client,_=self.hotel_user(self.a)
        state=client.get('/api/state',base_url=BASE).json
        self.assertEqual([h['id'] for h in state['hotels']],[self.a['id']])
        for secret in ('operator','limits','users','usage'):self.assertNotIn(secret,state)
        for route in ('/api/chat','/api/import'):
            self.assertEqual(self.post(route,{'hotelId':self.b['id'],'question':'Name?'},client=client).status_code,404)
        self.assertEqual(self.post('/api/hotels/'+self.b['id'],self.b,client=client,method='PUT').status_code,404)
        self.assertEqual(self.post('/api/ai-settings',{'key':''},client=client).status_code,403)
        self.assertEqual(self.post('/api/settings',{},client=client).status_code,403)

    def test_guest_and_admin_cannot_inject_other_hotel_facts_or_name(self):
        answer=self.ask(self.a,name='Hotel Beta',website=self.b['website'],facts=self.b['facts'])
        self.assertEqual(answer.status_code,200)
        sent=str(self.calls[0])
        self.assertIn('Hotel Alpha',sent);self.assertIn('ALPHA-ONLY',sent)
        self.assertNotIn('Hotel Beta',sent);self.assertNotIn('BETA-ONLY',sent)
        for key in ('usage','model','estimated_cost_usd','cache_ttl'):self.assertNotIn(key,answer.json)

    def test_csrf_and_foreign_origin_are_rejected(self):
        self.assertEqual(self.post('/api/settings',{},origin='https://evil.example').status_code,403)
        self.assertEqual(self.post('/api/settings',{},csrf=False).status_code,403)
        self.assertEqual(self.client.get('/api/state',base_url='https://evil.example').status_code,400)

    def test_invitation_is_one_time_scoped_and_revoked(self):
        token=self.db.invite('guest-hotel@example.test',self.a['id'])
        newer=self.db.invite('guest-hotel@example.test',self.a['id'])
        with self.assertRaises(ValueError):self.db.accept(token,PW)
        uid=self.db.accept(newer,PW)
        with self.assertRaises(ValueError):self.db.accept(newer,PW)
        client=self.app.test_client();self.sign_in(client,uid)
        self.assertTrue(client.get('/api/state',base_url=BASE).json['authenticated'])
        self.post('/api/users/'+uid+'/disable',{})
        self.assertFalse(client.get('/api/state',base_url=BASE).json['authenticated'])

    def test_privacy_details_block_public_release_even_with_ready_status(self):
        h=self.a
        self.assertEqual(self.start(h).status_code,403)
        self.assertEqual(self.client.get('/demo/'+h['id']+'/'+h['demoKey'],base_url=BASE).status_code,403)
        h=self.publish(h);self.db.set_setting('operator',{})
        self.assertEqual(self.start(h).status_code,403)
        self.assertEqual(self.client.get('/api/public/appearance/'+h['id'],headers={'Origin':'https://hotel.example'},base_url=BASE).status_code,403)

    def test_public_token_is_scoped_signed_and_invalidated_on_edit(self):
        h=self.publish(self.a);token=self.start(h).json['token']
        result=self.post('/api/public/chat',{'hotelId':self.b['id'],'question':'Name?','history':[],'token':token},csrf=False)
        self.assertEqual(result.status_code,403)
        self.assertEqual(self.post('/api/public/chat',{'token':token+'x'},csrf=False).status_code,401)
        self.db.save_hotel(profile({'greeting':'Neu'},h),h['revision'])
        self.assertEqual(self.post('/api/public/chat',{'hotelId':h['id'],'token':token,'question':'Name?'},csrf=False).status_code,403)
        with patch('time.time',return_value=time.time()+1900):
            self.assertEqual(self.post('/api/public/chat',{'hotelId':h['id'],'token':token,'question':'Name?'},csrf=False).status_code,401)

    def test_guest_chats_have_no_shared_private_history(self):
        h=self.publish(self.a);one=self.app.test_client();two=self.app.test_client()
        first=self.start(h,one).json['token'];second=self.start(h,two).json['token']
        self.assertNotEqual(first,second)
        self.post('/api/public/chat',{'hotelId':h['id'],'question':'Privat ALICE-ROOM-123','history':[{'role':'user','content':'ALICE-SECRET'}],'token':first},client=one,csrf=False)
        self.post('/api/public/chat',{'hotelId':h['id'],'question':'Neue Frage','history':[],'token':second},client=two,csrf=False)
        self.assertNotIn('ALICE',str(self.calls[-1]))
        with self.db.connect() as conn:
            dump='\n'.join(conn.iterdump())
        self.assertNotIn('ALICE',dump);self.assertNotIn('ROOM-123',dump)

    def test_cache_hit_costs_no_provider_call_even_when_budget_exhausted(self):
        self.ask(self.a)
        self.db.set_setting('limits',{'daily':0,'monthly':0,'hotelDaily':0})
        hit=self.ask(self.a)
        self.assertEqual(hit.json['mode'],'answer-cache');self.assertEqual(len(self.calls),1)
        missed=self.ask(self.a,'Was ist neu?')
        self.assertEqual(len(self.calls),1);self.assertIn('KI-Limit',missed.json['text'])

    def test_budget_reservations_are_atomic_across_threads(self):
        limits={'daily':.5,'monthly':.5,'hotelDaily':.5}
        def reserve(_):
            try:self.db.reserve(self.a['id'],.2,limits);return True
            except ValueError:return False
        with ThreadPoolExecutor(max_workers=8) as pool:result=list(pool.map(reserve,range(8)))
        self.assertEqual(sum(result),2)
        self.assertAlmostEqual(self.db.totals()['today'],.4)

    def test_timeout_keeps_cost_reservation(self):
        def failed(*args):raise TimeoutError()
        self.app.config['PROVIDER']=failed
        self.ask(self.a)
        self.assertGreater(self.db.totals()['today'],0)
        with self.db.connect() as conn:
            self.assertEqual(conn.execute('SELECT state FROM usage').fetchone()[0],'reserved')

    def test_key_is_encrypted_persistent_and_not_exposed(self):
        real='sk-ant-TEST-SAVED-KEY'
        with patch.object(knowledge,'validate_connection'):
            response=self.post('/api/ai-settings',{'key':real})
        self.assertEqual(response.status_code,200)
        self.assertNotIn(real,json.dumps(self.db.setting('anthropicKey')))
        self.assertNotIn(real,self.client.get('/api/state',base_url=BASE).text)
        new=create_app({**self.app.config,'PROVIDER':self.provider})
        self.assertTrue(new.test_client().get('/health',base_url=BASE).json['status']=='ok')
        self.post('/api/ai-settings',{'key':''})
        self.assertFalse(self.client.get('/api/state',base_url=BASE).json['aiReady'])

    def test_session_cookie_and_security_headers(self):
        client=self.app.test_client()
        response=self.post('/api/login',{'email':'owner@example.test','password':PW},client=client,csrf=False)
        cookie=response.headers['Set-Cookie']
        for flag in ('Secure','HttpOnly','SameSite=Lax'):self.assertIn(flag,cookie)
        self.assertIn("frame-ancestors 'self'",response.headers['Content-Security-Policy'])
        self.assertIn('max-age=',response.headers['Strict-Transport-Security'])

    def test_hotel_user_cannot_publish_or_add_origins(self):
        client,_=self.hotel_user(self.a)
        raw={**self.a,'status':'ready','allowedOrigins':['https://evil.example'],'privacyReviewed':True}
        response=self.post('/api/hotels/'+self.a['id'],raw,client=client,method='PUT')
        self.assertEqual(response.status_code,200)
        h=self.db.hotel(self.a['id']);self.assertEqual(h['status'],'draft');self.assertEqual(h['allowedOrigins'],[])

    def test_stale_editor_cannot_overwrite_newer_profile(self):
        self.db.save_hotel(profile({'name':'New Name'},self.a),self.a['revision'])
        self.assertEqual(self.post('/api/hotels/'+self.a['id'],self.a,method='PUT').status_code,400)

    def test_reset_revokes_old_sessions_and_token_is_one_time(self):
        client,uid=self.hotel_user(self.a)
        token=self.db.reset_link(uid)
        self.db.reset_password(token,PW+'new')
        self.assertFalse(client.get('/api/state',base_url=BASE).json['authenticated'])
        self.assertEqual(self.db.login('hotel@example.test',PW+'new'),uid)
        with self.assertRaises(ValueError):self.db.reset_password(token,PW)

    def test_login_is_throttled_and_logout_revokes_session(self):
        client=self.app.test_client()
        for _ in range(8):
            self.assertEqual(self.post('/api/login',{'email':'owner@example.test','password':'wrong'},client=client,csrf=False).status_code,401)
        self.assertEqual(self.post('/api/login',{'email':'owner@example.test','password':PW},client=client,csrf=False).status_code,429)
        self.post('/api/logout',{})
        self.assertFalse(self.client.get('/api/state',base_url=BASE).json['authenticated'])

    def test_widget_cors_and_frame_policy_only_allow_registered_websites(self):
        h=self.publish(self.a)
        accepted=self.client.get('/api/public/appearance/'+h['id'],headers={'Origin':'https://hotel.example'},base_url=BASE)
        self.assertEqual(accepted.status_code,200)
        self.assertEqual(accepted.headers['Access-Control-Allow-Origin'],'https://hotel.example')
        for secret in ('facts','website','demoKey','revision','allowedOrigins'):self.assertNotIn(secret,accepted.json)
        rejected=self.client.get('/api/public/appearance/'+h['id'],headers={'Origin':'https://evil.example'},base_url=BASE)
        self.assertEqual(rejected.status_code,403);self.assertNotIn('Access-Control-Allow-Origin',rejected.headers)
        frame=self.client.get('/widget/'+h['id']+'?parent=https://hotel.example',base_url=BASE)
        self.assertEqual(frame.status_code,200);self.assertIn('https://hotel.example',frame.headers['Content-Security-Policy'])

    def test_static_server_never_serves_secrets_or_database(self):
        for path in ('/data/hotelchat.sqlite3','/app.py','/store.py','/.env','/local-settings.json'):
            self.assertEqual(self.client.get(path,base_url=BASE).status_code,404)

    def test_backup_restore_preserves_accounts_sources_and_profiles(self):
        from backup import create_backup
        import sqlite3
        backup=create_backup(self.temp.name)
        restored=Path(self.temp.name)/'restored'/'hotelchat.sqlite3'
        restored.parent.mkdir()
        import shutil
        shutil.copy2(backup,restored)
        with sqlite3.connect(restored) as target:
            self.assertEqual(target.execute('PRAGMA quick_check').fetchone()[0],'ok')
        self.assertFalse(Path(str(backup)+'-wal').exists())
        recovery=Store(restored)
        self.assertEqual(recovery.login('owner@example.test',PW),self.owner)
        self.assertEqual(recovery.hotel(self.a['id'])['name'],'Hotel Alpha')
        self.assertTrue(knowledge.SourceStore(restored).get(self.a['id']))
        self.assertEqual(backup.stat().st_mode&0o777,0o600)

    def test_import_uses_only_server_saved_website(self):
        snapshot={'hotelId':self.a['id'],'requestedUrl':self.a['website'],'scannedAt':'new',
            'documents':[{'text':'New hotel facts','url':self.a['website'],'title':'New'}]}
        with patch('app.crawl',return_value=snapshot) as crawl:
            result=self.post('/api/import',{'hotelId':self.a['id'],'url':'https://evil.example','website':self.b['website']})
        self.assertEqual(result.status_code,200)
        crawl.assert_called_once_with(self.a['website'],self.a['id'])
        self.assertEqual(self.sources.get(self.a['id'])['scannedAt'],'new')

    def test_incomplete_usage_does_not_release_reservation(self):
        def no_usage(payload,key):
            result=self.provider(payload,key)
            result['usage']={}
            return result
        self.app.config['PROVIDER']=no_usage
        self.ask(self.a)
        self.assertGreater(self.db.totals()['today'],.01)
        with self.db.connect() as conn:
            self.assertEqual(conn.execute('SELECT state FROM usage').fetchone()[0],'reserved')

    def test_expired_invites_and_sessions_cannot_be_used(self):
        token=self.db.invite('expired@example.test',self.a['id'])
        with patch('time.time',return_value=time.time()+172801):
            with self.assertRaises(ValueError):self.db.accept(token,PW)
            self.assertFalse(self.client.get('/api/state',base_url=BASE).json['authenticated'])

    def test_html_in_hotel_name_is_rendered_as_text(self):
        h=self.db.save_hotel(profile({'name':'<script>alert(1)</script>'},self.a),self.a['revision'])
        result=self.client.get('/preview/'+h['id'],base_url=BASE)
        self.assertEqual(result.status_code,200)
        self.assertNotIn('<script>alert(1)</script>',result.text)
        self.assertIn('&lt;script&gt;',result.text)

    def test_encrypted_backup_is_owner_only_and_restores_all_hotels(self):
        from secure_backup import restore_export
        client,_=self.hotel_user(self.a)
        phrase='test-only-backup-password-with-entropy'
        self.assertEqual(self.post('/api/backup',{'passphrase':phrase},client=client).status_code,403)
        response=self.post('/api/backup',{'passphrase':phrase})
        self.assertEqual(response.status_code,200)
        self.assertNotIn(self.app.config['MASTER_KEY'].encode(),response.data)
        self.assertNotIn(b'owner@example.test',response.data)
        destination=Path(self.temp.name)/'encrypted-restore'
        restored=restore_export(response.data,phrase,destination)
        store=Store(restored)
        self.assertEqual(store.hotel(self.a['id'])['name'],'Hotel Alpha')
        self.assertEqual(store.hotel(self.b['id'])['name'],'Hotel Beta')
        self.assertEqual(store.login('owner@example.test',PW),self.owner)
        self.assertEqual((destination/'HOTELCHAT_MASTER_KEY.txt').read_text(),self.app.config['MASTER_KEY'])
        with store.connect() as db:
            for table in ('sessions','invites','resets'):
                self.assertEqual(db.execute('SELECT COUNT(*) FROM '+table).fetchone()[0],0)

    def test_encrypted_backup_wrong_password_and_overwrite_are_rejected(self):
        from secure_backup import restore_export
        phrase='test-only-backup-password-with-entropy'
        response=self.post('/api/backup',{'passphrase':phrase})
        destination=Path(self.temp.name)/'restored-secure'
        with self.assertRaises(ValueError):restore_export(response.data,'wrong-but-long-enough-password',destination)
        restore_export(response.data,phrase,destination)
        with self.assertRaises(ValueError):restore_export(response.data,phrase,destination)
        self.assertEqual(self.post('/api/backup',{'passphrase':'short'}).status_code,400)


if __name__=='__main__':unittest.main()
