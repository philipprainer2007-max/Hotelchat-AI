"""Start the new server locally without publishing or touching the old app."""
import json
import os
import secrets
import urllib.request
import webbrowser
from pathlib import Path
from werkzeug.serving import run_simple
from app import create_app

ROOT = Path(__file__).resolve().parent
settings_path = ROOT/'data'/'local-settings.json'
settings_path.parent.mkdir(parents=True,exist_ok=True)
if settings_path.exists():
    settings = json.loads(settings_path.read_text())
else:
    settings = {'master':secrets.token_urlsafe(48),'bootstrap':secrets.token_urlsafe(40)}
    fd = os.open(settings_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f: json.dump(settings,f)
from store import Store
db = Store(ROOT/'data'/'hotelchat.sqlite3')
url = 'http://127.0.0.1:8795/'
if not db.user_count():
    url += 'setup#'+settings['bootstrap']
if os.environ.get('HOTELCHAT_OPEN_BROWSER','1')=='1':
    webbrowser.open(url)
try:
    with urllib.request.urlopen('http://127.0.0.1:8795/health',timeout=1) as response:
        if response.status==200:
            print('Die neue HotelChat-Verwaltung läuft bereits.');raise SystemExit(0)
except (OSError,ValueError):
    pass
app = create_app({'PUBLIC_URL':'http://127.0.0.1:8795','LOCAL_DEV':True,
                  'MASTER_KEY':settings['master'],'BOOTSTRAP_TOKEN':settings['bootstrap']})
print('Neue HotelChat-Verwaltung: http://127.0.0.1:8795 (nur auf diesem Gerät)',flush=True)
run_simple('127.0.0.1',8795,app,use_reloader=False,use_debugger=False,
           threaded=True,request_handler=type('PrivateLog',(__import__('werkzeug.serving',fromlist=['WSGIRequestHandler']).WSGIRequestHandler,),{'log_request':lambda *args,**kwargs:None}))
