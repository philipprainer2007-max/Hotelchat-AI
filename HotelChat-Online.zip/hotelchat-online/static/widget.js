(() => {
  'use strict';
  let active;
  const defaults = { name: 'Maison Stadtpark', color: '#284c40', greeting: 'Willkommen! Wie kann ich Ihnen bei Ihrem Aufenthalt helfen?', position: 'right', label: 'Fragen Sie uns', round: true, logo: '', bookingUrl: '' };
  function mount(options = {}) {
    if (active) active.destroy();
    let config = { ...defaults, ...options };
    let opened = false, busy = false, destroyed = false, pendingRequest = null;
    const history=[];
    const host = document.createElement('div');
    host.setAttribute('data-hotelchat', '');
    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>
      :host{all:initial;position:fixed;bottom:24px;right:24px;z-index:2147483000;font-family:Arial,sans-serif;color:#1e302b;color-scheme:light}
      *{box-sizing:border-box}button,input,a{font:inherit}button,a{touch-action:manipulation}button{cursor:pointer}button:focus-visible,a:focus-visible,input:focus-visible{outline:3px solid #a37e30;outline-offset:3px}[hidden]{display:none!important}
      .launcher{border:0;display:flex;align-items:center;justify-content:center;gap:10px;min-height:60px;padding:0 22px;border-radius:32px;background:var(--brand);color:var(--ink);box-shadow:0 6px 25px #0003;font-size:14px;font-weight:600}.launcher.round{width:62px;height:62px;padding:0;border-radius:50%}.launcher.round .label{display:none}.icon{font-size:24px;line-height:1}.logo{height:32px;width:32px;border-radius:50%;object-fit:contain;background:#fff}.panel{position:absolute;bottom:80px;right:0;width:370px;max-width:calc(100vw - 32px);height:530px;max-height:calc(100dvh - 124px);background:#fff;border-radius:20px;box-shadow:0 16px 65px #14261c33;overflow:hidden;display:flex;flex-direction:column;border:1px solid #dfe6e1}.top{padding:21px 19px;background:var(--brand);color:var(--ink);display:flex;align-items:center;gap:12px}.avatar{width:39px;height:39px;border:1px solid currentColor;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}.headings{flex:1;min-width:0}.name{font-size:15px;font-weight:600;overflow-wrap:anywhere}.sub{font-size:11px;margin-top:5px;opacity:.85}.close{background:transparent;color:inherit;border:0;font-size:25px;width:40px;height:40px;border-radius:8px}.notice{text-align:center;font-size:11px;color:#66746b;background:#f3f6f3;padding:8px}.messages{flex:1;overflow:auto;min-height:0;padding:19px;display:flex;flex-direction:column;gap:12px;background:#fbfcfa}.message{font-size:13px;line-height:1.6;white-space:pre-wrap;overflow-wrap:anywhere;padding:12px 14px;border-radius:15px;max-width:92%;background:#edf1ec;align-self:flex-start}.message.user{background:var(--brand);color:var(--ink);align-self:flex-end}.suggestions{display:flex;gap:7px;flex-wrap:wrap;padding:0 19px 12px;background:#fbfcfa}.suggestions button{background:white;border:1px solid #dbe4dc;color:#30483b;border-radius:20px;font-size:11px;padding:9px 11px}.book{display:block;text-align:center;background:var(--brand);color:var(--ink);text-decoration:none;margin:0 16px 10px;border-radius:9px;padding:11px;font-size:13px}.entry{display:flex;gap:8px;align-items:center;padding:13px 16px;border-top:1px solid #e8ece7}.entry input{width:100%;min-width:0;border:0;background:#f2f5f0;border-radius:12px;padding:12px;font-size:14px;color:#203a2a}.send{border:0;border-radius:12px;background:var(--brand);color:var(--ink);width:43px;height:43px;flex-shrink:0;font-size:19px}.send:disabled{opacity:.5;cursor:wait}.footer{text-align:center;color:#788278;font-size:10px;padding:0 10px 12px}.left{right:auto;left:0}@media(max-width:480px){:host{bottom:16px;right:16px}.panel{width:calc(100vw - 32px);height:520px}.launcher{min-height:56px}.entry input{font-size:16px}}@media(prefers-reduced-motion:no-preference){.launcher{transition:transform .15s}.launcher:hover{transform:translateY(-2px)}}
    </style><section class="panel" role="dialog" aria-label="Hotel-Chat" hidden><header class="top"><div class="avatar" aria-hidden="true">✦</div><div class="headings"><div class="name"></div><div class="sub">Ihr digitaler Hotel-Concierge</div></div><button class="close" type="button" aria-label="Chat schließen">×</button></header><div class="notice">KI-Concierge · Hotelinformationen</div><div class="messages" role="log" aria-live="polite" aria-relevant="additions" aria-label="Chatverlauf"></div><div class="suggestions"><button type="button">Check-in</button><button type="button">Frühstück</button><button type="button">Anreise</button></div><a class="book" target="_blank" rel="noopener noreferrer" hidden>Jetzt buchen ↗</a><form class="entry"><input aria-label="Ihre Nachricht" placeholder="Ihre Frage …" maxlength="2000" autocomplete="off"><button class="send" aria-label="Nachricht senden" type="submit">↑</button></form><div class="footer">HotelChat · KI mit Quellen</div></section><button class="launcher" type="button" aria-label="Hotel-Chat öffnen" aria-expanded="false"><span class="icon" aria-hidden="true">💬</span><img class="logo" alt="" hidden><span class="label"></span></button>`;
    const $ = selector => root.querySelector(selector);
    const panel = $('.panel'), launcher = $('.launcher'), input = $('input'), messages = $('.messages');
    function message(text, role = 'bot', sources = []) {
      const el = document.createElement('div'); el.className = 'message ' + role; el.textContent = text; messages.append(el);
      if (sources.length) {
        const list = document.createElement('div'); list.style.cssText = 'margin-top:10px;display:flex;flex-direction:column;gap:6px;font-size:11px;';
        const seen = new Set();
        for (const source of sources) {
          let url; try { url = new URL(source.url); } catch {}
          const key = url ? url.href.replace(/\/$/, '') : 'manual:' + (source.title || '');
          if (seen.has(key)) continue;
          seen.add(key);
          if (url?.protocol === 'https:') {
            const link = document.createElement('a'); link.href = url.href; link.target = '_blank'; link.rel = 'noopener noreferrer';
            link.textContent = 'Quelle: ' + (source.title || url.hostname); link.style.color = 'inherit'; list.append(link);
          } else if (!source.url) { const label = document.createElement('span'); label.textContent = source.title || 'Eigene Hotelangabe'; list.append(label); }
        }
        if (list.childElementCount) el.append(list);
      }
      messages.scrollTop = messages.scrollHeight;
      return el;
    }
    function toggle(value) { opened = value; panel.hidden = !opened; launcher.setAttribute('aria-expanded', String(opened)); launcher.setAttribute('aria-label', opened ? 'Chat schließen' : 'Hotel-Chat öffnen'); if (opened) input.focus(); else launcher.focus(); window.dispatchEvent(new CustomEvent('hotelchat:toggle',{detail:{opened,hotelId:config.id}})); }
    function update(next) {
      if(next.id&&config.id&&next.id!==config.id)throw new Error('Für ein anderes Hotel muss ein neuer Chat geöffnet werden.');
      config = { ...config, ...next };
      const color = /^#[0-9a-f]{6}$/i.test(config.color) ? config.color : defaults.color;
      const rgb = [1,3,5].map(i => parseInt(color.slice(i,i+2),16)/255).map(v => v <= .04045 ? v/12.92 : ((v+.055)/1.055)**2.4);
      const luminance = rgb[0]*.2126 + rgb[1]*.7152 + rgb[2]*.0722;
      host.style.setProperty('--brand',color); host.style.setProperty('--ink',luminance > .179 ? '#10241a' : '#ffffff');
      const left = config.position === 'left'; host.style.right = left ? 'auto' : '16px'; host.style.left = left ? '16px' : 'auto'; panel.classList.toggle('left', left);
      $('.name').textContent = config.name || defaults.name; $('.label').textContent = config.label || defaults.label; launcher.classList.toggle('round', !!config.round);
      if(config.facts){$('.notice').textContent=config.knowledge?.length?'Hotelwissen mit Quellen':'Gespeichertes Hotelprofil';$('.footer').textContent=window.HotelChatService?'HotelChat · Antwortmodus wird bei der Frage angezeigt':'Offline-Vorschau · eingeschränkte Quellensuche';}
      const img = $('.logo'); const logoAllowed = /^data:image\/(png|jpeg|webp|gif);base64,/i.test(config.logo || ''); img.hidden = !logoAllowed; $('.icon').hidden = logoAllowed;
      if(logoAllowed) img.src=config.logo; else img.removeAttribute('src');
      $('.avatar').replaceChildren();
      if(logoAllowed) {const copy=img.cloneNode(); copy.hidden=false; $('.avatar').append(copy);} else $('.avatar').textContent='✦';
      let booking; try {const url = new URL(config.bookingUrl); if(url.protocol==='https:') booking=url.href;} catch {}
      $('.book').hidden = !booking; if(booking) $('.book').href=booking; else $('.book').removeAttribute('href');
      if(!messages.children.length) message(config.greeting || defaults.greeting);
      else if(next.greeting !== undefined) messages.firstElementChild.textContent = config.greeting || defaults.greeting;
    }
    async function send(text) {
      text = String(text || '').trim(); if (!text || busy) return;
      message(text.slice(0,2000),'user'); input.value=''; busy=true; $('.send').disabled=true;
      const typing=message('Passende Hotelinformationen werden gesucht …');
      try {
        if(window.HotelChatService&&config.id){
          const request=new AbortController();pendingRequest=request;
          const timeout=setTimeout(()=>request.abort(),45000);
          let result;
          try{result=await window.HotelChatService.request({hotelId:config.id,name:config.name,website:config.website||'',facts:{...config.facts},question:text,history:history.slice(-8)},request.signal);}finally{clearTimeout(timeout);}
          if(destroyed)return;
          typing.remove();message(result.text,'bot',result.sources||[]);$('.notice').textContent=result.notice||'Antwort aus Hotelinformationen';$('.footer').textContent=result.mode==='ai'?'HotelChat · KI mit Quellen':'HotelChat · Quellensuche ohne KI';
          if(result.mode==='answer-cache')$('.footer').textContent='HotelChat · Hotelwissen mit Quellen';
          history.push({role:'user',content:text},{role:'assistant',content:result.text});if(history.length>8)history.splice(0,history.length-8);return;
        }
        const q=text.toLocaleLowerCase('de');
        let answer;
        if(config.facts && window.HotelChatData) answer=window.HotelChatData.answer(config,text);
        else if(/check|eincheck|ankunft/.test(q)) answer='Beispiel: Der Check-in ist ab 15:00 Uhr möglich, der Check-out bis 11:00 Uhr. Für eine frühere Anreise wenden Sie sich bitte an die Rezeption.';
        else if(/früh|breakfast|essen/.test(q)) answer='Beispiel: Unser Frühstück servieren wir täglich von 7:00 bis 10:30 Uhr. Dies sind Demodaten; später stammen die Angaben aus dem jeweiligen Hotelprofil.';
        else if(/anreise|park|adresse|bahnhof/.test(q)) answer='Hier zeigt Ihr Concierge später die bestätigte Adresse, Anreise- und Parkinformationen Ihres Hotels. In dieser Vorschau sind noch keine echten Hoteldaten hinterlegt.';
        else answer='Danke für Ihre Nachricht! Diese Vorschau zeigt, wie sich der Chat auf Ihrer Website anfühlt. Für echte Antworten verbinden wir anschließend die KI und die Informationen Ihres Hotels.';
        typing.remove();message(answer);
      } catch(error){if(!destroyed){typing.remove();message(error.name==='AbortError'?'Die Antwort dauert gerade zu lange. Bitte erneut versuchen.':error.message||'Die Verbindung zum Chatdienst ist unterbrochen. Bitte erneut versuchen.');}}
      finally {busy=false;pendingRequest=null;if(!destroyed){$('.send').disabled=false;input.focus();}}
    }
    launcher.addEventListener('click',()=>toggle(!opened)); $('.close').addEventListener('click',()=>toggle(false)); root.addEventListener('keydown',e=>{if(e.key==='Escape'&&opened){e.preventDefault();toggle(false);}});
    $('.entry').addEventListener('submit',e=>{e.preventDefault();send(input.value);}); root.querySelectorAll('.suggestions button').forEach(btn=>btn.addEventListener('click',()=>send(btn.textContent)));
    if(config.embedded){const embeddedStyle=document.createElement('style');embeddedStyle.textContent=':host{inset:0!important}.panel,.panel.left{position:fixed;inset:0;width:100vw;max-width:100vw;height:100dvh;max-height:100dvh;border-radius:16px}.launcher{display:none}';root.append(embeddedStyle);}
    document.body.append(host); update(config);
    active = {update,open:()=>toggle(true),close:()=>toggle(false),destroy:()=>{destroyed=true;pendingRequest?.abort();host.remove();}}; return active;
  }
  window.HotelChat = {mount};
})();
