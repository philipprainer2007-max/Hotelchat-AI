(() => {
  'use strict';
  const mode = document.body.dataset.mode;
  const storageKey = 'hotelchat.auth-link.' + mode;
  let token = location.hash.slice(1);
  // Keep the one-time link in this tab across reloads, never the password.
  if (['setup', 'accept', 'reset'].includes(mode)) {
    try {
      if (token) sessionStorage.setItem(storageKey, token);
      else token = sessionStorage.getItem(storageKey) || '';
    } catch {}
  }
  history.replaceState(null, '', location.pathname);
  const form = document.getElementById('auth-form');
  const button = form.querySelector('button');
  const message = document.getElementById('message');
  if (mode !== 'login' && !token) {
    button.disabled = true;
    message.textContent = mode === 'setup'
      ? 'Bitte öffne „Neue HotelChat-Verwaltung starten.command“ erneut. Die Startdatei öffnet den geschützten Einrichtungslink für dich. Danach kannst du hier deinen Zugang anlegen.'
      : 'Bitte öffne den vollständigen Einladungs- oder Rücksetzlink erneut.';
  }
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (mode !== 'login' && !token) return;
    button.disabled = true;
    message.textContent = 'Wird geprüft …';
    try {
      const response = await fetch('/api/' + mode, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: document.getElementById('email')?.value,
          password: document.getElementById('password').value,
          token
        })
      });
      const data = await response.json();
      if (!response.ok) throw Error(data.error);
      document.getElementById('password').value = '';
      try { sessionStorage.removeItem(storageKey); } catch {}
      token = '';
      location.assign('/');
    } catch (error) {
      message.textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });
})();
