"""Import an explicit local profile export plus its existing source snapshots."""
import argparse
import json
import os
from pathlib import Path
from app import profile
from store import Store
from knowledge import SourceStore

parser = argparse.ArgumentParser(description='Lokale Hotelprofile in die neue Verwaltung übernehmen.')
parser.add_argument('profiles',type=Path)
parser.add_argument('--sources',type=Path,required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parent
destination = Path(os.environ.get('HOTELCHAT_DATA_DIR',str(root/'data')))/'hotelchat.sqlite3'
db = Store(destination)
source = SourceStore(args.sources)
target = SourceStore(destination)
items = json.loads(args.profiles.read_text())
if not isinstance(items,list): raise SystemExit('Die Exportdatei muss eine Liste von Hotelprofilen enthalten.')
for raw in items:
    if not isinstance(raw,dict): continue
    # Fictitious example hotels are not production tenants.
    if 'Beispielhotel' in raw.get('city','') or raw.get('name') in ('Maison Stadtpark','Alpenruhe Lodge','Casa Marina'): continue
    # Keep the old ID for existing source data; never merge different hotel IDs.
    hid = raw.get('id','')
    if not __import__('re').fullmatch(r'hotel-[a-zA-Z0-9-]{1,80}',hid): continue
    if db.hotel(hid):
        print('Bereits vorhanden; unverändert:',raw.get('name',hid));continue
    h = profile(raw)
    h['id'] = hid
    h['status'] = 'draft'
    h['allowedOrigins'] = []
    for key in ('privacyReviewed','answersReviewed','contractsReviewed'): h[key]=False
    db.save_hotel(h)
    snapshot = source.get(hid,raw.get('website',''))
    if snapshot: target.save(snapshot)
    print('Als Entwurf übernommen:',h['name'])
